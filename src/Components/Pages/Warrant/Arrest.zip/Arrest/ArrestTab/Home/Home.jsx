
import React, { useEffect, useState, useContext } from 'react'
import { useLocation, useNavigate } from "react-router-dom";
import Select from "react-select";
import DatePicker from "react-datepicker";
import { Decrypt_Id_Name, base64ToString, filterPassedTime, getShowingDateText, getShowingMonthDateYear, stringToBase64, tableCustomStyles } from '../../../../Common/Utility';
import { AddDeleteUpadate, AddDelete_Img, fetchPostData } from '../../../../hooks/Api';
import { Comman_changeArrayFormat, } from '../../../../Common/ChangeArrayFormat';
import { toastifyError, toastifySuccess } from '../../../../Common/AlertMsg';
import { AgencyContext } from '../../../../../Context/Agency/Index';
import { RequiredFieldIncident } from '../../../Utility/Personnel/Validation';
import ConfirmModal from '../../ConfirmModal';
import defualtImage from '../../../../../img/uploadImage.png'
import { Carousel } from 'react-responsive-carousel';
import DeletePopUpModal from '../../../../Common/DeleteModal';
import ChangesModal from '../../../../Common/ChangesModal';
import IdentifyFieldColor from '../../../../Common/IdentifyFieldColor';
import DataTable from 'react-data-table-component';
import MasterNameModel from '../../../MasterNameModel/MasterNameModel';
import { useDispatch, useSelector } from 'react-redux';
import { get_LocalStoreData } from '../../../../../redux/actions/Agency';
import ImageModel from '../../../ImageModel/ImageModel';

const Home = ({ setShowJuvinile, setShowPoliceForce, DecArrestId, setStatus, status, }) => {

    const useQuery = () => {
        const params = new URLSearchParams(useLocation().search);
        return {
            get: (param) => params.get(param)
        };
    };

    let DecEIncID = 0, DecChargeId = 0

    const query = useQuery();
    var openPage = query?.get('page');
    var IncID = query?.get("IncId");
    var ArrestId = query?.get("ArrestId");
    var IncNo = query?.get("IncNo");
    var IncSta = query?.get("IncSta");
    var ArrNo = query?.get("ArrNo");
    var Name = query?.get("Name");

    var ArrestSta = query?.get('ArrestSta');

    if (!IncID) { DecEIncID = 0; }
    else { DecEIncID = parseInt(base64ToString(IncID)); }

    if (!ArrestId) { DecArrestId = 0; }
    else { DecArrestId = parseInt(base64ToString(ArrestId)); }


    const dispatch = useDispatch();
    const localStoreData = useSelector((state) => state.Agency.localStoreData);
    const uniqueId = sessionStorage.getItem('UniqueUserID') ? Decrypt_Id_Name(sessionStorage.getItem('UniqueUserID'), 'UForUniqueUserID') : '';
    const navigate = useNavigate();

    const { get_Arrest_Count, arrestFilterData, ArresteeID, setArresteeID, get_Data_Arrest, setArrestName, policeForceDrpData, get_Police_Force, arresteeDrpData, get_Arrestee_Drp_Data, changesStatusCount, setChangesStatus, changesStatus, get_Incident_Count } = useContext(AgencyContext);

    const [arrestDate, setArrestDate] = useState();
    const [arrestingAgencyDrpData, setAgencyNameDrpData] = useState([]);
    const [arrestTypeDrpData, setArrestTypeDrpData] = useState([]);
    const [supervisorDrpData, setSuperVisorDrpData] = useState([]);
    const [juvenileDispoDrp, setJuvenileDisDrp] = useState([]);
    const [rightGivenCode, setRightGivenCode] = useState('N');
    const [ArrestID, setArrestID] = useState('');
    const [Editval, setEditval] = useState();
    const [showModal, setShowModal] = useState(false);
    const [arresteeChange, setArresteeChange] = useState();
    const [clickedRow, setClickedRow] = useState(null);
    const [modalStatus, setModalStatus] = useState(false);
    const [imageid, setImageId] = useState('');
    const [multiImage, setMultiImage] = useState([]);
    const [MainIncidentID, setMainIncidentID] = useState('');
    const [loginAgencyID, setloginAgencyID] = useState('');
    const [loginPinID, setloginPinID,] = useState('');
    const [nameModalStatus, setNameModalStatus] = useState(false);
    const [possessionID, setPossessionID] = useState('');
    // const [arresteeID, setArresteeID] = useState([]);
    const [possenSinglData, setPossenSinglData] = useState([]);
    const [uploadImgFiles, setuploadImgFiles] = useState([]);
    const [imageModalStatus, setImageModalStatus] = useState(false);

    const [value, setValue] = useState({
        'ArrestID': '', 'AgencyID': '', 'ArrestNumber': '', 'IncidentID': '', 'CreatedByUserFK': '', 'IsJuvenileArrest': '',
        'ArrestDtTm': '', 'ArrestingAgencyID': '', 'ArrestTypeID': '', 'SupervisorID': '', 'PoliceForceID': '',
        'RightsGivenID': '', 'JuvenileDispositionID': '', 'PhoneNo': '', 'GivenByID': '', 'PrimaryOfficerID': '',
        'ArresteeID': '', 'ArresteeLable': 0, 'ModifiedByUserFK': '',
    });

    const [errors, setErrors] = useState({
        'ArresteeIDError': '', 'PrimaryOfficerIDError': '', 'ArrestDtTmError': '',
    })

    const [imgData, setImgData] = useState({
        "PictureTypeID": '',
        "ImageViewID": '',
        "ImgDtTm": '',
        "OfficerID": '',
        "Comments": '',
        "DocumentID": ''
    })

    useEffect(() => {
        if (DecEIncID) {
            setMainIncidentID(DecEIncID); get_Data_Arrest(DecEIncID); get_Incident_Count(DecEIncID)
            get_Arrestee_Drp_Data('', 0, DecEIncID);
        }
    }, [DecEIncID, nameModalStatus, possessionID]);

    useEffect(() => {
        if (!localStoreData?.AgencyID || !localStoreData?.PINID) {
            if (uniqueId) dispatch(get_LocalStoreData(uniqueId));
        }
    }, []);

    useEffect(() => {
        if (localStoreData) {
            setloginAgencyID(localStoreData?.AgencyID); setloginPinID(localStoreData?.PINID);
        }
    }, [localStoreData]);

    useEffect(() => {
        if (loginAgencyID) {
            setValue({
                ...value,
                'IncidentID': DecEIncID, 'ArrestID': DecArrestId, 'CreatedByUserFK': loginPinID, 'AgencyID': loginAgencyID,
            });
            get_Head_Of_Agency(loginAgencyID);
        }
    }, [loginAgencyID]);

    useEffect(() => {
        if (DecArrestId) {
            setArrestID(DecArrestId); GetSingleData(DecArrestId); get_Arrest_Count(DecArrestId);
        } else {
            get_Arrest_Count(''); GetSingleData(''); setMultiImage(''); setStatus(false); setArrestID('');
        }
    }, [DecArrestId, DecEIncID]);


    useEffect(() => {
        document.addEventListener('load', function () {
            document.getElementById('#myModal').modal('showModal');
        });
    }, [])

    const check_Validation_Error = (e) => {
        if (RequiredFieldIncident(value.ArresteeID)) {
            setErrors(prevValues => { return { ...prevValues, ['ArresteeIDError']: RequiredFieldIncident(value.ArresteeID) } })
        }
        if (RequiredFieldIncident(value.PrimaryOfficerID)) {
            setErrors(prevValues => { return { ...prevValues, ['PrimaryOfficerIDError']: RequiredFieldIncident(value.PrimaryOfficerID) } })
        }
        if (RequiredFieldIncident(value.ArrestDtTm)) {
            setErrors(prevValues => { return { ...prevValues, ['ArrestDtTmError']: RequiredFieldIncident(value.ArrestDtTm) } })
        }
    }
    // Check All Field Format is True Then Submit 
    const { ArresteeIDError, PrimaryOfficerIDError, ArrestDtTmError } = errors

    useEffect(() => {
        if (PrimaryOfficerIDError === 'true' && ArrestDtTmError === 'true' && ArresteeIDError === 'true' && !showModal) {
            if (ArrestID && (ArrestSta === true || ArrestSta || 'true')) { update_Arrest() }
            else {
                insert_Arrest_Data();
            }
        }
    }, [PrimaryOfficerIDError, ArrestDtTmError, ArresteeIDError, showModal])

    useEffect(() => {
        if (ArrestID) {
            GetSingleData(ArrestID);
        } else {
            reset_Value();
        }
    }, [ArrestID]);

    const GetSingleData = (ArrestID) => {
        const val = { 'ArrestID': ArrestID, }
        fetchPostData('Arrest/GetSingleData_Arrest', val)
            .then((res) => {
                if (res.length > 0) {
                    setEditval(res);
                } else { setEditval([]) }
            })
    }

    useEffect(() => {
        if (ArrestID) {
            get_Arrest_MultiImage(ArrestID)
            get_Arrestee_Drp_Data('', 0, DecEIncID);
            setValue({
                ...value,
                'ArrestNumber': Editval[0]?.ArrestNumber, 'IsJuvenileArrest': Editval[0]?.IsJuvenileArrest,
                'ArrestDtTm': Editval[0]?.ArrestDtTm ? getShowingDateText(Editval[0]?.ArrestDtTm) : "", 'ArrestingAgencyID': Editval[0]?.ArrestingAgencyID,
                'ArrestTypeID': Editval[0]?.ArrestTypeID, 'SupervisorID': Editval[0]?.SupervisorID, 'PoliceForceID': Editval[0]?.PoliceForceID,
                'ArresteeID': Editval[0]?.ArresteeID, 'RightsGivenID': Editval[0]?.RightsGivenID, 'JuvenileDispositionID': Editval[0]?.JuvenileDispositionID,
                'PhoneNo': Editval[0]?.PhoneNo, 'GivenByID': Editval[0]?.GivenByID, 'PrimaryOfficerID': Editval[0]?.PrimaryOfficerID, 'ArrestID': Editval[0]?.ArrestID,
                'ModifiedByUserFK': loginPinID,
            });
            setPossessionID(Editval[0]?.ArresteeID);
            setArrestName(Editval[0]?.Arrestee_Name ? Editval[0]?.Arrestee_Name : '');
            setArrestDate(Editval[0]?.ArrestDtTm ? new Date(Editval[0]?.ArrestDtTm) : '');
            setRightGivenCode(Get_Given_Code(Editval, policeForceDrpData))

            if (Editval[0]?.IsJuvenileArrest === true || Editval[0]?.IsJuvenileArrest === 'true') {
                setShowJuvinile(true);
            } else {
                setShowJuvinile(false);
            }
        } else {
            setValue({
                ...value,
                'ArrestNumber': '', 'IsJuvenileArrest': '', 'ArrestDtTm': '', 'ArrestingAgencyID': '', 'ArrestTypeID': '', 'SupervisorID': '',
                'PoliceForceID': '', 'RightsGivenID': '', 'JuvenileDispositionID': '', 'PhoneNo': '', 'GivenByID': '', 'PrimaryOfficerID': '',
                'ModifiedByUserFK': '',
            }); setArrestDate();
        }
    }, [Editval, changesStatusCount])

    const reset_Value = () => {
        setShowJuvinile(false); setShowPoliceForce(false);
        setValue({
            ...value,
            'ArrestNumber': '', 'IsJuvenileArrest': '', 'ArrestDtTm': '', 'ArrestingAgencyID': '', 'ArrestTypeID': '', 'SupervisorID': '', 'PoliceForceID': '',
            'ArresteeID': '', 'RightsGivenID': '', 'JuvenileDispositionID': '', 'PhoneNo': '', 'GivenByID': '', 'PrimaryOfficerID': '', 'ModifiedByUserFK': '',
        });
        setArrestDate(); setMultiImage(''); setuploadImgFiles('');
    }

    useEffect(() => {
        policeForceDrpData?.filter(val => {
            if (val.value === value?.PoliceForceID) {
                if (val.id === 'Y') {
                    setShowPoliceForce(true)
                } else {
                    setShowPoliceForce(false);
                }
            }
        });
    }, [value?.PoliceForceID]);

    useEffect(() => {
        if (loginAgencyID || loginPinID || MainIncidentID) {
            get_Arresting_DropDown(loginAgencyID, loginPinID);
            Get_ArrestType_Drp(loginAgencyID); get_Head_Of_Agency(loginAgencyID); get_Arrest_juvenile_Drp(loginAgencyID);
        }
        if (policeForceDrpData?.length === 0) {
            get_Police_Force();
        }
    }, [loginAgencyID])

    const get_Arrest_juvenile_Drp = (loginAgencyID) => {
        const val = { AgencyID: loginAgencyID }
        fetchPostData('ArrestJuvenileDisposition/GetDataDropDown_ArrestJuvenileDisposition', val).then((data) => {
            if (data) {
                setJuvenileDisDrp(Comman_changeArrayFormat(data, 'ArrestJuvenileDispositionID', 'Description'));
            } else {
                setJuvenileDisDrp([])
            }
        })
    };

    const get_Head_Of_Agency = (loginAgencyID) => {
        const val = { AgencyID: loginAgencyID }
        fetchPostData('DropDown/GetData_HeadOfAgency', val).then((data) => {
            if (data) {
                setSuperVisorDrpData(Comman_changeArrayFormat(data, 'PINID', 'HeadOfAgency'));
            } else {
                setSuperVisorDrpData([])
            }
        })
    };

    const get_Arresting_DropDown = (loginAgencyID, loginPinID) => {
        const val = { AgencyID: loginAgencyID, PINID: loginPinID }
        fetchPostData('Agency/GetData_Agency', val).then((data) => {
            if (data) {
                setAgencyNameDrpData(Comman_changeArrayFormat(data, 'AgencyID', 'Agency_Name'))
            } else {
                setAgencyNameDrpData([]);
            }
        })
    }

    const Get_ArrestType_Drp = (loginAgencyID) => {
        const val = { AgencyID: loginAgencyID }
        fetchPostData('ArrestType/GetDataDropDown_ArrestType', val).then((data) => {
            if (data) {
                setArrestTypeDrpData(Comman_changeArrayFormat(data, 'ArrestTypeID', 'Description'))
            } else {
                setArrestTypeDrpData([]);
            }
        })
    }

    const HandleChange = (e) => {
        if (e.target.name === "IsJuvenileArrest") {
            setChangesStatus(true)
            setValue({ ...value, [e.target.name]: e.target.checked });
        } else if (e.target.name === 'PhoneNo') {
            var ele = e.target.value.replace(/[^0-9\s]/g, "")
            if (ele.length === 10) {
                var cleaned = ('' + ele).replace(/\D/g, '');
                var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
                if (match) {
                    setChangesStatus(true)
                    setValue({ ...value, [e.target.name]: match[1] + '-' + match[2] + '-' + match[3] });
                }
            } else {
                ele = e.target.value.split('-').join('').replace(/[^0-9\s]/g, "");
                setChangesStatus(true)
                setValue({ ...value, [e.target.name]: ele });
            }
        }
        else {
            setChangesStatus(true)
            setValue({ ...value, [e.target.name]: e.target.value });
        }
    };

    useEffect(() => {
        if (rightGivenCode !== "Y") {
            setValue({ ...value, ['GivenByID']: '' })
        }
    }, [rightGivenCode])

    useEffect(() => {
        if (!value.IsJuvenileArrest || value.IsJuvenileArrest === 'false') {
            setShowJuvinile(false);
            setValue({ ...value, ['JuvenileDispositionID']: '', ['PhoneNo']: '' });
        } else {
            setShowJuvinile(true);
        }
    }, [value.IsJuvenileArrest])


    const insert_Arrest_Data = () => {
        AddDeleteUpadate('Arrest/Insert_Arrest', value).then((res) => {
            if (res.success) {
                if (res.ArrestID) {
                    navigate(`/Arrest-Home?IncId=${IncID}&IncNo=${IncNo}&IncSta=${IncSta}&ArrestId=${stringToBase64(res?.ArrestID)}&ArrNo=${res?.ArrestNumber}&Name=${res?.Arrestee_Name}&ArrestSta=${true}&ChargeSta${true}`)
                    toastifySuccess(res.Message); get_Arrest_Count(ArrestID); get_Data_Arrest(MainIncidentID);
                    setArrestID(res.ArrestID); setStatus(false);
                    if (uploadImgFiles?.length > 0) {
                        upload_Image_File(res.ArrestID);
                        setuploadImgFiles('');
                    }
                }
                setErrors({ ...errors, ['ArresteeIDError']: '' }); get_Incident_Count(MainIncidentID);
            }
        })
    }

    const update_Arrest = () => {
        AddDeleteUpadate('Arrest/Update_Arrest', value).then((res) => {
            const parsedData = JSON.parse(res.data);
            const message = parsedData.Table[0].Message;
            toastifySuccess(message);
            setChangesStatus(false); get_Data_Arrest(MainIncidentID);
            setErrors({ ...errors, ['ArresteeIDError']: '' })
            if (uploadImgFiles?.length > 0) {
                upload_Image_File();
                setuploadImgFiles('');
            }
        })
    }

    const DeleteArrest = () => {
        const val = { 'ArrestID': ArrestID, 'DeletedByUserFK': loginPinID }
        AddDeleteUpadate('Arrest/Delete_Arrest', val).then((res) => {
            if (res) {
                const parsedData = JSON.parse(res.data);
                const message = parsedData.Table[0].Message;
                toastifySuccess(message);
                get_Data_Arrest(MainIncidentID);
                get_Incident_Count(MainIncidentID)
                get_Arrest_Count(ArrestID); reset_Value(); setStatusFalse()
            } else console.log("Somthing Wrong");
        })
    }

    const startRef = React.useRef();
    const startRef1 = React.useRef();

    const onKeyDown = (e) => {
        if (e.keyCode === 9 || e.which === 9) {
            startRef.current.setOpen(false);
            startRef1.current.setOpen(false);
        }
    };

    const columns = [
        {
            width: '150px',
            name: 'Arrest Number',
            selector: (row) => row.ArrestNumber,
            sortable: true
        },
        {
            width: '150px',
            name: 'Agency Name',
            selector: (row) => row.Agency_Name,
            sortable: true
        },
        {
            width: '200px',
            name: 'Supervisor Name',
            // selector: (row) => row.Supervisor_Name,
            selector: (row) => <>{row?.Supervisor_Name ? row?.Supervisor_Name.substring(0, 60) : ''}{row?.Supervisor_Name?.length > 40 ? '  . . .' : null} </>,
            sortable: true
        },
        {
            name: 'PoliceForce Description',
            selector: (row) => row.PoliceForce_Description,
            sortable: true
        },
        {
            name: <p className='text-end' style={{ position: 'absolute', top: '7px', right: 10 }}>Delete</p>,
            cell: row => <>

                <div style={{ position: 'absolute', top: 4, right: 10 }}>
                    <span to={`#`} onClick={() => setArrestID(row.ArrestID)} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#DeleteModal">
                        <i className="fa fa-trash"></i>
                    </span>

                </div>
            </>
        }
    ]

    const set_Edit_Value = (row) => {
        if (row.ArrestID) {
            navigate(`/Arrest-Home?IncId=${IncID}&IncNo=${IncNo}&IncSta=${IncSta}&ArrestId=${stringToBase64(row?.ArrestID)}&ArrNo=${row?.ArrestNumber}&Name=${row?.Arrestee_Name}&ArrestSta=${true}&ChargeSta=${false}`)
            setArrestID(row?.ArrestID); get_Arrest_Count(row?.ArrestID);
        }
    }

    const setStatusFalse = () => {
        navigate(`/Arrest-Home?IncId=${IncID}&IncNo=${IncNo}&IncSta=${IncSta}&ArrestId=${('')}&ArrestSta=${false}&ChargeSta=${false}`)
        setArrestID(''); setClickedRow(null); reset_Value(); setErrors(''); get_Arrest_Count('');
        setPossessionID(''); setPossenSinglData([]);
    }

    const conditionalRowStyles = [
        {
            when: row => row.ArrestID === ArrestID,
            style: {
                backgroundColor: '#001f3fbd',
                color: 'white',
                cursor: 'pointer',
            },
        },
    ];

    //-------------------------Image---------------------------

    const get_Arrest_MultiImage = (ArrestID) => {
        const val = { 'ArrestID': ArrestID }
        const val1 = { 'ArrestID': 0 }
        fetchPostData('Arrest/GetData_ArrestPhoto', openPage === 'ArrestSearch' ? val1 : val)
            .then((res) => {
                if (res) {
                    setMultiImage(res);
                }
                else { setMultiImage([]); }
            })
    }

    // to update image data
    const update_Vehicle_MultiImage = () => {
        const val = { "ModifiedByUserFK": loginPinID, "AgencyID": loginAgencyID, "PictureTypeID": imgData?.PictureTypeID, "ImageViewID": imgData?.ImageViewID, "ImgDtTm": imgData?.ImgDtTm, "OfficerID": imgData?.OfficerID, "Comments": imgData?.Comments, "DocumentID": imgData?.DocumentID }
        AddDelete_Img('PropertyVehicle/Update_PropertyVehiclePhotoDetail', val)
            .then((res) => {
                if (res.success) {
                    toastifySuccess(res.Message);
                    get_Arrest_MultiImage(ArrestID);
                }
                else {
                    toastifyError(res?.Message);
                }
            })
    }

    const upload_Image_File = (arrID) => {
        const formdata = new FormData();
        const newData = [];
        for (let i = 0; i < uploadImgFiles.length; i++) {
            const { file, imgData } = uploadImgFiles[i];
            const val = {
                'ArrestID': ArrestID ? ArrestID : arrID,
                'CreatedByUserFK': loginPinID,
                'AgencyID': loginAgencyID,
                'PictureTypeID': imgData?.PictureTypeID,
                'ImageViewID': imgData?.ImageViewID,
                'ImgDtTm': imgData?.ImgDtTm,
                'OfficerID': imgData?.OfficerID,
                'Comments': imgData?.Comments
            }
            const val1 = {
                'ArrestID': 0,
                'CreatedByUserFK': loginPinID,
                'AgencyID': loginAgencyID,
                'PictureTypeID': imgData?.PictureTypeID,
                'ImageViewID': imgData?.ImageViewID,
                'ImgDtTm': imgData?.ImgDtTm,
                'OfficerID': imgData?.OfficerID,
                'Comments': imgData?.Comments
            }
            const values = JSON.stringify(openPage === 'ArrestSearch' ? val1 : val);
            formdata.append("file", file);
            newData.push(values);
        }
        formdata.append("Data", JSON.stringify(newData));
        AddDelete_Img('Arrest/Insert_ArrestPhoto', formdata).then((res) => {
            if (res.success) {
                get_Arrest_MultiImage(ArrestID ? ArrestID : arrID);
                setuploadImgFiles([]);

            }
        }).catch(err => console.log(err))
    }

    const delete_Image_File = (e) => {
        const value = {
            'PhotoID': imageid,
            'DeletedByUserFK': loginPinID
        }
        AddDelete_Img('Arrest/Delete_ArrestPhoto', value).then((data) => {
            if (data.success) {
                get_Arrest_MultiImage(ArrestID);
                setModalStatus(false)
                setImageId('');
            } else {
                toastifyError(data?.Message);
            }
        });
    }

    // Custom Style
    const colourStyles = {
        control: (styles) => ({
            ...styles, backgroundColor: "#fce9bf",
            height: 20,
            minHeight: 30,
            fontSize: 14,
            margintop: 2,
            boxShadow: 0,
        }),
    };

    // custuom style withoutColor
    const customStylesWithOutColor = {
        control: base => ({
            ...base,
            height: 20,
            minHeight: 30,
            fontSize: 14,
            margintop: 2,
            boxShadow: 0,
        }),
    };

    //--------------------possession---------------------------------//

    const GetSingleDataPassion = (nameID, masterNameID) => {
        const val = { 'NameID': nameID, 'MasterNameID': masterNameID }
        fetchPostData('MasterName/GetSingleData_MasterName', val).then((res) => {
            if (res) {
                setPossenSinglData(res);
            } else { setPossenSinglData([]); }
        })
    }

    useEffect(() => {
        if (possessionID) { setValue({ ...value, ['ArresteeID']: parseInt(possessionID) }) }
    }, [possessionID, arresteeDrpData]);



    const ChangeDropDown = (e, name) => {
        if (e) {
            if (name === 'RightsGivenID') {
                setRightGivenCode(e.id)
                setChangesStatus(true)
                setValue({ ...value, [name]: e.value })

            } else if (name === 'ArresteeID') {
                if (!e.Gendre_Description || !e.Race_Description || !e.DateOfBirth || !e.LastName) {
                    setShowModal(true);
                    setArresteeChange(e);
                    setPossessionID(e.value);
                }
                setChangesStatus(true)
                setValue({ ...value, [name]: e.value })
            } else {
                setChangesStatus(true)
                setValue({ ...value, [name]: e.value })
            }
        } else if (e === null) {
            if (name === 'RightsGivenID') {
                setChangesStatus(true)
                setValue({ ...value, [name]: null })
                setRightGivenCode('N')
            } else {
                setChangesStatus(true)
                setValue({ ...value, [name]: null })
            }
            if (e) {
                if (name === 'ArresteeID') {
                    setPossessionID(e.value); setPossenSinglData([]); setValue({ ...value, [name]: e.value });
                    setChangesStatus(true)
                }

            } else {
                if (name === 'ArresteeID') {
                    setPossessionID(''); setPossenSinglData([]); setValue({ ...value, [name]: null });
                    setChangesStatus(true)
                }

            }
        } else {
            setChangesStatus(true)
            setValue({
                ...value, [name]: null
            })
        }
    }

    // const ChangeDropDown = (e, name) => {
    //     if (e) {
    //         if (name === 'RightsGivenID') {
    //             setRightGivenCode(e.id);
    //             setChangesStatus(true);
    //             setValue({ ...value, [name]: e.value });
    //         } else if (name === 'ArresteeID') {
    //             if (!e.Gendre_Description || !e.Race_Description || !e.DateOfBirth || !e.LastName) {
    //                 setShowModal(true);
    //                 setArresteeChange(e);
    //                 setPossessionID(e.value);
    //                 const currentDate = new Date();
    //                 const updatedData = arresteeDrpData.map(item => {
    //                     if (item.DateOfBirth) {
    //                         const birthDate = new Date(item.DateOfBirth);
    //                         const age = currentDate.getFullYear() - birthDate.getFullYear();
    //                         const monthDiff = currentDate.getMonth() - birthDate.getMonth();
    //                         if (monthDiff < 0 || (monthDiff === 0 && currentDate.getDate() < birthDate.getDate())) {
    //                             age--;
    //                         }
    //                         if (age < 18 || age == null) {
    //                             setValue({ ...value, ['IsJuvenileArrest']: true });
    //                         } else {
    //                             setValue({ ...value, ['IsJuvenileArrest']: false });
    //                         }
    //                     }
    //                     return updatedData;
    //                 });
    //             }
    //             setChangesStatus(true);
    //             setValue({ ...value, [name]: e.value });
    //         } else {
    //             setChangesStatus(true);
    //             setValue({ ...value, [name]: e.value });
    //         }
    //     } else { // Handle the case where e is null (value is cleared)
    //         setChangesStatus(true);
    //         setValue(prevValue => ({ ...prevValue, [name]: null }));
    //         if (name === 'ArresteeID') {
    //             setPossessionID('');
    //             setPossenSinglData([]); setShowModal(false);
    //             setValue(prevValue => ({ ...prevValue, [name]: null, 'IsJuvenileArrest': false }));
    //         } else if (name === 'RightsGivenID') {
    //             setRightGivenCode('N');
    //         }
    //     }
    // };


    return (
        <>
            <div className="col-12 " id="display-not-form">
                <div className="row">
                    <div className="col-12 col-md-12 col-lg-11 pt-2 p-0">
                        <div className="row px-2">
                            <div className="col-12 col-md-12 col-lg-12 mb-0 ml-5 pl-4 ">
                                <div className="form-check">
                                    <input className="form-check-input " type="checkbox" onChange={HandleChange} name='IsJuvenileArrest' value={value?.IsJuvenileArrest} checked={value?.IsJuvenileArrest} id="flexCheckDefault" />
                                    <label className="form-check-label" htmlFor="flexCheckDefault">
                                        Juvenile Arrest
                                    </label>
                                </div>
                            </div>
                            <div className="col-2 col-md-2 col-lg-1  mt-2 ">
                                <label htmlFor="" className='new-label '>Arrest No.</label>
                            </div>
                            <div className="col-4 col-md-4 col-lg-2  text-field  mt-1">
                                <input type="text" name='ArrestNumber' value={value?.ArrestNumber} className="readonlyColor" onChange={''} id='ArrestNumber' required readOnly />
                            </div>
                            <div className="col-2 col-md-2 col-lg-2 mt-2 ">
                                <label htmlFor="" className='new-label'>Arresting Agency</label>
                            </div>
                            <div className="col-4 col-md-4 col-lg-3 ">
                                <Select
                                    name="ArrestingAgencyID"
                                    value={arrestingAgencyDrpData?.filter((obj) => obj.value === value?.ArrestingAgencyID)}
                                    styles={customStylesWithOutColor}
                                    isClearable
                                    options={arrestingAgencyDrpData}
                                    onChange={(e) => { ChangeDropDown(e, 'ArrestingAgencyID') }}
                                    placeholder="Select..."
                                />
                            </div>
                            <div className="col-2 col-md-2 col-lg-1 mt-2">
                                <label htmlFor="" className='new-label'>Arrest Type</label>
                            </div>
                            <div className="col-4 col-md-4 col-lg-3 ">
                                <Select
                                    name="ArrestTypeID"
                                    value={arrestTypeDrpData?.filter((obj) => obj.value === value?.ArrestTypeID)}
                                    styles={customStylesWithOutColor}
                                    isClearable
                                    options={arrestTypeDrpData}
                                    onChange={(e) => { ChangeDropDown(e, 'ArrestTypeID') }}
                                    placeholder="Select..."
                                />
                            </div>

                            <div className="col-2 col-md-2 col-lg-1 mt-2 ">
                                <label htmlFor="" className='new-label'>Supervisor</label>
                            </div>
                            <div className="col-4 col-md-4 col-lg-2 mt-1">
                                <Select
                                    name='SupervisorID'
                                    styles={customStylesWithOutColor}
                                    value={supervisorDrpData?.filter((obj) => obj.value === value?.SupervisorID)}
                                    isClearable
                                    options={supervisorDrpData}
                                    onChange={(e) => ChangeDropDown(e, 'SupervisorID')}
                                    placeholder="Select..."
                                />
                            </div>
                            <div className="col-2 col-md-2 col-lg-2 mt-2">
                                <label htmlFor="" className='new-label'>Arrest Date/Time {errors.ArrestDtTmError !== 'true' ? (
                                    <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.ArrestDtTmError}</p>
                                ) : null}</label>
                            </div>
                            <div className="col-4 col-md-4 col-lg-3 ">
                                <DatePicker
                                    id='ArrestDtTm'
                                    name='ArrestDtTm'
                                    ref={startRef1}
                                    onKeyDown={onKeyDown}
                                    onChange={(date) => { setChangesStatus(true); setArrestDate(date); setValue({ ...value, ['ArrestDtTm']: date ? getShowingMonthDateYear(date) : null }) }}
                                    className='requiredColor'
                                    dateFormat="MM/dd/yyyy HH:mm"
                                    timeInputLabel
                                    showYearDropdown
                                    showMonthDropdown
                                    dropdownMode="select"
                                    isClearable={value?.ArrestDtTm ? true : false}
                                    selected={arrestDate}
                                    placeholderText={value?.ArrestDtTm ? value.ArrestDtTm : 'Select...'}
                                    showTimeSelect
                                    timeIntervals={1}
                                    timeCaption="Time"
                                    autoComplete="Off"
                                    filterTime={filterPassedTime}
                                    maxDate={new Date()}
                                />
                            </div>

                            <div className="col-2 col-md-2 col-lg-1 mt-2 px-0">
                                <label htmlFor="" className='new-label px-0'>Police Force</label>
                            </div>
                            <div className="col-4 col-md-4 col-lg-3 mt-1">
                                <Select
                                    name='PoliceForceID'
                                    styles={customStylesWithOutColor}
                                    value={policeForceDrpData?.filter((obj) => obj.value === value?.PoliceForceID)}
                                    isClearable
                                    options={policeForceDrpData}
                                    onChange={(e) => ChangeDropDown(e, 'PoliceForceID')}
                                    placeholder="Select..."
                                />
                            </div>
                        </div>
                    </div>
                    <div className=" col-4 col-md-4 col-lg-1 ">
                        <div className="img-box" >
                            <Carousel autoPlay={true} className="carousel-style" showArrows={true} showThumbs={false} showStatus={false} >
                                {
                                    multiImage.length > 0 ?
                                        multiImage?.map((item) => (
                                            <div key={item.index} data-toggle="modal" data-target="#ImageModel" onClick={() => { setImageModalStatus(true) }}>
                                                <img src={`data:image/png;base64,${item.Photo}`} style={{ height: '105px' }} />

                                            </div>
                                        ))
                                        :
                                        <div data-toggle="modal" data-target="#ImageModel" onClick={() => { setImageModalStatus(true) }}>
                                            <img src={defualtImage} style={{ height: '105px' }} />
                                        </div>
                                }
                            </Carousel>
                        </div>
                    </div>
                </div>
                <fieldset>
                    <legend>Name Information </legend>
                    <div className="row ">
                        <div className="col-12 col-md-12 col-lg-11 pt-2 p-0 ">
                            <div className="row ">
                                <div className="col-2 col-md-2 col-lg-1 mt-2 ">
                                    <label htmlFor="" className='new-label'>Arrestee {errors.ArresteeIDError !== 'true' ? (
                                        <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.ArresteeIDError}</p>
                                    ) : null}</label>
                                </div>
                                <div className="col-4 col-md-4 col-lg-5">
                                    {
                                        openPage ?
                                            <Select
                                                name="ArresteeID"
                                                styles={colourStyles}
                                                options={arresteeDrpData}
                                                value={arresteeDrpData?.filter((obj) => obj.value === value?.ArresteeLable)}
                                                isClearable
                                                onChange={(e) => ChangeDropDown(e, 'ArresteeID')}
                                                placeholder="Select..."
                                            />
                                            :
                                            <Select
                                                name="ArresteeID"
                                                styles={colourStyles}
                                                options={arresteeDrpData}
                                                value={arresteeDrpData?.filter((obj) => obj.value === value?.ArresteeID)}
                                                isClearable
                                                isDisabled={ArrestID ? true : false}
                                                onChange={(e) => ChangeDropDown(e, 'ArresteeID')}
                                                placeholder="Select..."
                                            />
                                    }
                                </div>
                                <div className="col-1  " data-toggle="modal" data-target="#MasterModal"  >
                                    <span
                                        className=" btn btn-sm bg-green text-white"
                                        onClick={() => {
                                            if (possessionID) { GetSingleDataPassion(possessionID); }
                                            setNameModalStatus(true);
                                        }}
                                    >
                                        <i className="fa fa-plus" > </i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
                <fieldset>
                    <legend>Rights Information </legend>
                    <div className="row">
                        <div className="col-12 col-md-12 col-lg-11 pt-2 p-0 ">
                            <div className="row ">
                                <div className="col-2 col-md-2 col-lg-1 mt-2 px-0">
                                    <label htmlFor="" className='new-label px-0'>Rights Given</label>
                                </div>
                                <div className="col-4 col-md-4 col-lg-2 mt-1">
                                    <Select
                                        name='RightsGivenID'
                                        styles={customStylesWithOutColor}
                                        value={policeForceDrpData?.filter((obj) => obj.value === value?.RightsGivenID)}
                                        isClearable
                                        options={policeForceDrpData}
                                        onChange={(e) => ChangeDropDown(e, 'RightsGivenID')}
                                        placeholder="Select..."
                                    />
                                </div>
                                <div className="col-2 col-md-2 col-lg-2 mt-2 ">
                                    <label htmlFor="" className='new-label'>Given By</label>
                                </div>
                                <div className="col-4 col-md-4 col-lg-3 mt-1">
                                    <Select
                                        name='GivenByID'
                                        menuPlacement='top'
                                        styles={customStylesWithOutColor}
                                        value={supervisorDrpData?.filter((obj) => obj.value === value?.GivenByID)}
                                        isClearable
                                        options={supervisorDrpData}
                                        onChange={(e) => ChangeDropDown(e, 'GivenByID')}
                                        placeholder="Select..."
                                        isDisabled={rightGivenCode === 'N' ? true : false}
                                    />
                                </div>
                                <div className="col-2 col-md-2 col-lg-2 mt-2 ">
                                    <label htmlFor="" className='new-label '>Primary Officer{errors.PrimaryOfficerIDError !== 'true' ? (
                                        <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.PrimaryOfficerIDError}</p>
                                    ) : null}</label>
                                </div>
                                <div className="col-4 col-md-4 col-lg-2 mt-1">
                                    <Select
                                        name='PrimaryOfficerID'
                                        menuPlacement='top'
                                        styles={colourStyles}
                                        value={supervisorDrpData?.filter((obj) => obj.value === value?.PrimaryOfficerID)}
                                        isClearable
                                        options={supervisorDrpData}
                                        onChange={(e) => ChangeDropDown(e, 'PrimaryOfficerID')}
                                        placeholder="Select..."
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
                {/* juvenile */}
                <fieldset>
                    <legend>Juvenile Disposition</legend>
                    <div className="row">
                        <div className="col-12 col-md-12 col-lg-11 pt-2 p-0 ">
                            <div className="row">
                                <div className="col-2 col-md-2 col-lg-1 mt-2 ">
                                    <label htmlFor="" className='new-label'>Disposition</label>
                                </div>
                                <div className="col-4 col-md-4 col-lg-4 mt-1">
                                    <Select
                                        name='JuvenileDispositionID'
                                        menuPlacement='top'
                                        styles={customStylesWithOutColor}
                                        value={juvenileDispoDrp?.filter((obj) => obj.value === value?.JuvenileDispositionID)}
                                        isClearable
                                        options={juvenileDispoDrp}
                                        onChange={(e) => ChangeDropDown(e, 'JuvenileDispositionID')}
                                        placeholder="Select..."
                                        isDisabled={value?.IsJuvenileArrest ? false : true}
                                    />
                                </div>
                                <div className="col-2 col-md-2 col-lg-5 mt-2 ">
                                    <label htmlFor="" className='new-label'>Phone No:</label>
                                </div>
                                <div className="col-4 col-md-4 col-lg-2 mt-1 text-field">
                                    <input type="text" maxLength={10} name='PhoneNo' id='PhoneNo' className={`${value.IsJuvenileArrest === false ? "readonlyColor" : ''}`} value={value?.PhoneNo} onChange={HandleChange} required disabled={value.IsJuvenileArrest === true ? false : true} />
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </div>
            <div className="col-12  text-right p-0" style={{ marginTop: '-10px' }}>
                <button type="button" className="btn btn-sm btn-success  mr-1" onClick={() => { setStatusFalse(); }}>New</button>
                <button type="button" className="btn btn-sm btn-success  mr-1" data-toggle="modal" data-target="#myModal" onClick={() => { if (!showModal) { check_Validation_Error(); } }}>
                    {ArrestID && (ArrestSta === true || ArrestSta || 'true') ? 'Update' : 'Save'}
                </button>
            </div>
            {
                modalStatus &&
                <div className="modal" id="myModal2" style={{ background: "rgba(0,0,0, 0.5)", transition: '0.5s' }} data-backdrop="false">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="box text-center py-5">
                                <h5 className="modal-title mt-2" id="exampleModalLabel">Do you want to Delete ?</h5>
                                <div className="btn-box mt-3">
                                    <button type="button" onClick={delete_Image_File} className="btn btn-sm text-white" style={{ background: "#ef233c" }} >Delete</button>
                                    <button type="button" onClick={() => { setImageId(''); setModalStatus(false); }} className="btn btn-sm btn-secondary ml-2"> Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            }
            <div className="col-12 pt-1">
                <DataTable
                    dense
                    columns={columns}
                    data={arrestFilterData}
                    selectableRowsHighlight
                    highlightOnHover
                    responsive
                    // subHeaderComponent={<ThreeFilter Data={arrestData} setResult={setArrestFilterData} Col1='ArrestNumber' Col2='Agency_Name' Col3='Supervisor_Name' searchName1='Arrest Number' searchName2='Agency Name' searchName3='Supervisor Name' />}
                    onRowClicked={(row) => {
                        setClickedRow(row);
                        set_Edit_Value(row);
                    }}
                    fixedHeaderScrollHeight='170px'
                    conditionalRowStyles={conditionalRowStyles}
                    fixedHeader
                    persistTableHead={true}
                    customStyles={tableCustomStyles}
                />
            </div>
            <ConfirmModal {...{ showModal, setShowModal, arresteeChange, value, possessionID, setPossessionID, setValue, setErrors }} />
            <DeletePopUpModal func={DeleteArrest} />
            <ChangesModal func={check_Validation_Error} />
            <IdentifyFieldColor />
            <MasterNameModel {...{ value, setValue, nameModalStatus, setNameModalStatus, loginPinID, loginAgencyID, possessionID, setPossessionID, possenSinglData }} />
            <ImageModel multiImage={multiImage} value={value} primaryOfficerID={supervisorDrpData} setMultiImage={setMultiImage} uploadImgFiles={uploadImgFiles} setuploadImgFiles={setuploadImgFiles} ChangeDropDown={ChangeDropDown} modalStatus={modalStatus} setModalStatus={setModalStatus} imageId={imageid} setImageId={setImageId} imageModalStatus={imageModalStatus} setImageModalStatus={setImageModalStatus} delete_Image_File={delete_Image_File} setImgData={setImgData} imgData={imgData} updateImage={update_Vehicle_MultiImage} />
        </>
    )
}

export default Home

const Get_Code = (data, dropDownData) => {
    const result = data?.map((sponsor) =>
        (sponsor.ArresteeID)
    )
    const result2 = dropDownData?.map((sponsor) => {
        if (sponsor.value === result[0]) {
            return { value: result[0], label: sponsor.label, id: sponsor.id }
        }
    }
    )
    const val = result2.filter(function (element) {
        return element !== undefined;
    });
    return val[0]?.label
}

const Get_Given_Code = (data, dropDownData) => {
    const result = data?.map((sponsor) =>
        (sponsor.RightsGivenID)
    )
    const result2 = dropDownData?.map((sponsor) => {
        if (sponsor.value === result[0]) {
            return { value: result[0], label: sponsor.label, id: sponsor.id }
        }
    }
    )
    const val = result2.filter(function (element) {
        return element !== undefined;
    });
    return val[0]?.id
}