import React, { useState, useEffect, useContext, useCallback } from 'react'
import { Link } from 'react-router-dom';
import { Decrypt_Id_Name, getShowingWithOutTime, tableCustomStyles } from '../../../../Common/Utility';
import { AddDeleteUpadate, fetchPostData } from '../../../../hooks/Api';
import DataTable from 'react-data-table-component';
import { toastifySuccess } from '../../../../Common/AlertMsg';
import DeletePopUpModal from '../../../../Common/DeleteModal';
import { AgencyContext } from '../../../../../Context/Agency/Index';
import { Comman_changeArrayFormat } from '../../../../Common/ChangeArrayFormat';
import { RequiredFieldIncident } from '../../../Utility/Personnel/Validation';
import Select from "react-select";
import DatePicker from "react-datepicker";
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { get_LocalStoreData } from '../../../../../redux/actions/Agency';

const Juvenile = (props) => {
  const { DecArrestId } = props

  const dispatch = useDispatch();
  const localStoreData = useSelector((state) => state.Agency.localStoreData);
  const uniqueId = sessionStorage.getItem('UniqueUserID') ? Decrypt_Id_Name(sessionStorage.getItem('UniqueUserID'), 'UForUniqueUserID') : '';

  const { localStoreArray, get_LocalStorage, get_Arrest_Count } = useContext(AgencyContext);
  const [clickedRow, setClickedRow] = useState(null);

  const [juvenileData, setJuvenileData] = useState();
  const [arrestJuvenileID, setArrestJuvenileID] = useState();
  const [status, setStatus] = useState(false);
  const [modal, setModal] = useState(false);
  const [loder, setLoder] = useState(false)
  const [updateStatus, setUpdateStatus] = useState(0)

  const [loginAgencyID, setLoginAgencyID] = useState('')
  const [arrestID, setArrestID] = useState('')
  const [loginPinID, setLoginPinID] = useState('');
  const [editval, setEditval] = useState();
  const [headOfAgency, setHeadOfAgency] = useState([]);
  const [parentContactDtTm, setParentContactDtTm] = useState();
  // const localStore = {
  //   Value: "",
  //   UniqueId: sessionStorage.getItem('UniqueUserID') ? Decrypt_Id_Name(sessionStorage.getItem('UniqueUserID'), 'UForUniqueUserID') : '',
  //   Key: JSON.stringify({ AgencyID: "", IncidentID: '', ArrestID: '', }),
  // }

  // useEffect(() => {
  //   if (!localStoreArray.AgencyID || !localStoreArray.PINID) {
  //     get_LocalStorage(localStore);
  //   }
  // }, []);

  // // Onload Function
  // useEffect(() => {
  //   if (localStoreArray) {
  //     if (localStoreArray?.AgencyID && localStoreArray?.PINID) {
  //       setLoginAgencyID(localStoreArray?.AgencyID);
  //       setLoginPinID(parseInt(localStoreArray?.PINID));
  //       if (localStoreArray.ArrestID) {
  //         setArrestID(localStoreArray?.ArrestID);
  //       } else {
  //         setArrestID('')
  //       }
  //     }
  //   }
  // }, [localStoreArray])

  useEffect(() => {
    if (!localStoreData?.AgencyID || !localStoreData?.PINID) {
      if (uniqueId) dispatch(get_LocalStoreData(uniqueId));
    }
  }, []);

  useEffect(() => {
    if (localStoreData) {
      setLoginPinID(localStoreData?.PINID); setLoginAgencyID(localStoreData?.AgencyID);
    }
  }, [localStoreData]);

  useEffect(() => {
    if (DecArrestId) {
      setValue({
        ...value,
        'ParentContactDtTm': '', 'ContactByID': '', 'ParentAddress': '', 'ParentName': '', 'ParentPhone': "",
        'CreatedByUserFK': loginPinID,
        'ArrestID': DecArrestId,

      })
      get_Data_Juvenile(DecArrestId); setArrestID(DecArrestId);
    }
  }, [DecArrestId]);

  const [value, setValue] = useState({
    'ParentContactDtTm': '', 'ContactByID': '', 'ParentAddress': '', 'ParentName': '', 'ParentPhone': "", 'ArrestID': arrestID,
    'CreatedByUserFK': loginPinID,
  })

  const [errors, setErrors] = useState({
    'ParentContactDtTmErrors': '', 'ContactByIDErrors': '',

  })

  useEffect(() => {
    if (arrestID) setValue(pre => { return { ...pre, 'ArrestID': arrestID, 'CreatedByUserFK': loginPinID, } })
  }, [arrestID, updateStatus]);

  const check_Validation_Error = (e) => {
    if (RequiredFieldIncident(value.ParentContactDtTm)) {
      setErrors(prevValues => { return { ...prevValues, ['ParentContactDtTmErrors']: RequiredFieldIncident(value.ParentContactDtTm) } })
    }
    if (RequiredFieldIncident(value.ContactByID)) {
      setErrors(prevValues => { return { ...prevValues, ['ContactByIDErrors']: RequiredFieldIncident(value.ContactByID) } })
    }
  }
  // Check All Field Format is True Then Submit 
  const { ParentContactDtTmErrors, ContactByIDErrors, } = errors

  useEffect(() => {
    if (ParentContactDtTmErrors === 'true' && ContactByIDErrors === 'true') {
      if (status) update_Juvenile()
      else Add_Type()
    }
  }, [ParentContactDtTmErrors, ContactByIDErrors])

  useEffect(() => {
    if (arrestJuvenileID) {
      GetSingleData()
    }
  }, [arrestJuvenileID, updateStatus])

  const GetSingleData = () => {
    const val = { 'ArrestJuvenileID': arrestJuvenileID, }
    fetchPostData('ArrestJuvenile/GetSingleData_ArrestJuvenile', val)
      .then((res) => {
        if (res) {
          setEditval(res);
        } else { setEditval([]) }
      })
  }

  useEffect(() => {
    if (status) {
      setValue({
        ...value,
        'ArrestJuvenileID': editval[0]?.ArrestJuvenileID,
        'ParentContactDtTm': editval[0].ParentContactDtTm ? getShowingWithOutTime(editval[0].ParentContactDtTm) : '',
        'ParentAddress': editval[0]?.ParentAddress ? editval[0]?.ParentAddress.trim() : '',
        'ContactByID': editval[0]?.ContactByID,
        'ParentName': editval[0]?.ParentName ? editval[0]?.ParentName : '',
        'ParentPhone': editval[0]?.ParentPhone,
        'ModifiedByUserFK': loginPinID,
      })
      setParentContactDtTm(editval[0]?.ParentContactDtTm ? new Date(editval[0]?.ParentContactDtTm) : '');
    } else {
      setValue({
        ...value,
        'ParentContactDtTm': '', ' ContactByID': '', 'ParentAddress': '', 'ParentName': '',
      })
    }
  }, [editval])

  useEffect(() => {
    if (loginAgencyID) {
      Get_ContactByID(loginAgencyID);
    }
  }, [loginAgencyID])

  const Get_ContactByID = (loginAgencyID) => {
    const val = {
      AgencyID: loginAgencyID
    }
    fetchPostData('DropDown/GetData_HeadOfAgency', val).then((data) => {
      if (data) {
        setHeadOfAgency(Comman_changeArrayFormat(data, 'PINID', 'HeadOfAgency'));
      }
      else {
        setHeadOfAgency([])
      }
    })
  };

  const handleChange = (e) => {
    if (e.target.name === 'ParentPhone') {
      let ele = e.target.value.replace(/[^0-9\s]/g, "")
      if (ele.length === 10) {
        const cleaned = ('' + ele).replace(/\D/g, '');
        const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
        if (match) {
          setValue({
            ...value,
            [e.target.name]: match[1] + '-' + match[2] + '-' + match[3]
          });
        }
      } else {
        ele = e.target.value.split('-').join('').replace(/[^0-9\s]/g, "");
        setValue({
          ...value,
          [e.target.name]: ele
        });
      }
    }
    else {
      setValue({
        ...value,
        [e.target.name]: e.target.value,
      });
    }
  }

  const ChangeDropDown = (e, name) => {
    if (e) {
      setValue({
        ...value,
        [name]: e.value
      })
    } else setValue({
      ...value,
      [name]: null
    })
  }

  const Add_Type = () => {
    const { ParentContactDtTm, ContactByID, ParentAddress, ParentName, ParentPhone, CreatedByUserFK, ArrestID } = value;

    const val = {
      'ParentContactDtTm': ParentContactDtTm, 'ContactByID': ContactByID, 'ParentAddress': ParentAddress, 'ParentName': ParentName,
      'CreatedByUserFK': loginPinID, 'ArrestID': DecArrestId, 'ParentPhone': ParentPhone
    }
    AddDeleteUpadate('ArrestJuvenile/Insert_ArrestJuvenile', val).then((res) => {
      const parsedData = JSON.parse(res.data);
      const message = parsedData.Table[0].Message;
      toastifySuccess(message);
      get_Data_Juvenile(arrestID);
      get_Arrest_Count(arrestID)
      setModal(false);
      setStatus(false)
      reset()

    })
  }

  const update_Juvenile = () => {
    AddDeleteUpadate('ArrestJuvenile/Update_ArrestJuvenile', value).then((res) => {
      const parsedData = JSON.parse(res.data);
      const message = parsedData.Table[0].Message;
      toastifySuccess(message);
      get_Data_Juvenile(arrestID);
      setModal(false);
      setStatus(false)
      reset();
    })
  }

  const closeModal = () => {
    reset();
    setModal(false);
  }

  const reset = () => {
    setValue({
      ...value,
      'ParentContactDtTm': '', 'ContactByID': '', 'ParentAddress': '', 'ParentName': '', 'ParentPhone': "",
    }); setParentContactDtTm('');
    setErrors({
      ...errors, 'ParentContactDtTmErrors': '', 'ContactByIDErrors': '',
    });
  }

  const escFunction = useCallback((event) => {
    if (event.key === "Escape") {
      reset()
    }
  }, []);

  useEffect(() => {
    document.addEventListener("keydown", escFunction, false);
    return () => {
      document.removeEventListener("keydown", escFunction, false);
    };
  }, [escFunction]);

  const startRef = React.useRef();

  const onKeyDown = (e) => {
    if (e.keyCode === 9 || e.which === 9) {
      startRef.current.setOpen(false);
    }
  };

  const colourStyles = {
    control: (styles) => ({
      ...styles, backgroundColor: "#fce9bf",
      height: 20,
      minHeight: 35,
      fontSize: 14,
      margintop: 2,
      boxShadow: 0,
    }),
  }
  useEffect(() => {
    if (arrestID) {
      get_Data_Juvenile(arrestID);
    }
  }, [arrestID])

  const get_Data_Juvenile = (arrestID) => {
    const val = {
      'ArrestID': arrestID,
    }
    fetchPostData('ArrestJuvenile/GetData_ArrestJuvenile', val).then((res) => {
      if (res) {
        setJuvenileData(res); setLoder(true)
      } else {
        setJuvenileData(); setLoder(true)
      }
    })
  }

  const columns = [
    // {
    //   width: '120px',
    //   name: <p className='text-end' style={{ position: 'absolute', top: 8, }}>Action</p>,
    //   cell: row =>
    //     <div className="div" style={{ position: 'absolute', top: 4, left: 20 }}>
    //       <Link to={''} onClick={(e) => { set_Edit_Value(e, row) }} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#PinModal" >
    //         <i className="fa fa-edit"></i></Link>
    //     </div>

    // },
    {
      name: 'Date/Time',
      selector: (row) => getShowingWithOutTime(row.ParentContactDtTm),
      sortable: true
    },
    {
      name: 'Parent Name',
      selector: (row) => row.ParentName,
      sortable: true
    },
    // {
    //   name: 'Parent Phone',
    //   selector: (row) => row.ParentPhone,
    //   sortable: true
    // },
    {
      name: 'Contacted By',
      selector: (row) => row.ContactBy_Name,
      sortable: true
    },
    {
      name: <p className='text-end' style={{ position: 'absolute', top: 8, right: 0 }}>Delete</p>,
      cell: row =>
        <div className="div" style={{ position: 'absolute', top: 4, right: 5 }}>

          <span to={`#`} onClick={() => { setArrestJuvenileID(row.ArrestJuvenileID); }} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#DeleteModal">
            <i className="fa fa-trash"></i>
          </span>

        </div>

    }
  ]
  const conditionalRowStyles = [
    {
      when: row => row === clickedRow,
      style: {
        backgroundColor: '#001f3fbd',
        color: 'white',
        cursor: 'pointer',
      },
    },
  ];
  const set_Edit_Value = (row) => {
    setStatus(true);
    setModal(true); setErrors('')
    setUpdateStatus(updateStatus + 1);
    setArrestJuvenileID(row.ArrestJuvenileID);
    get_Arrest_Count(row.ArrestID)

  }

  const DeleteJuvenile = () => {
    const val = {
      'ArrestJuvenileID': arrestJuvenileID,
      'DeletedByUserFK': loginPinID
    }
    AddDeleteUpadate('ArrestJuvenile/Delete_ArrestJuvenile', val).then((res) => {
      if (res) {
        const parsedData = JSON.parse(res.data);
        const message = parsedData.Table[0].Message;
        toastifySuccess(message);
        get_Data_Juvenile(arrestID); reset()
        get_Arrest_Count(arrestID); setStatus(false);
      } else console.log("Somthing Wrong");
    })
  }

  const setStatusFalse = (e) => {
    setModal(true); setStatus(false);
    setUpdateStatus(updateStatus + 1); reset(''); setErrors('')

  }

  return (
    <>
      <div className="col-12">
        <div className="row">
          <div className="col-2 col-md-2 col-lg-2 mt-3">
            <label htmlFor="" className='new-label'>Parent Name</label>
          </div>
          <div className="col-4 col-md-4 col-lg-4 mt-2 text-field ">
            <input type="text" className='ParentName' name='ParentName' value={value?.ParentName} onChange={handleChange} />
          </div>
          <div className="col-2 col-md-2 col-lg-2 mt-2 pt-2">
            <label htmlFor="" className='new-label'>Parent Contact Date{errors.ParentContactDtTmErrors !== 'true' ? (
              <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.ParentContactDtTmErrors}</p>
            ) : null}</label>
          </div>
          <div className="col-4 col-md-4 col-lg-4 ">
            <DatePicker
              ref={startRef}
              onKeyDown={onKeyDown}
              id='ParentContactDtTm'
              name='ParentContactDtTm'
              className='requiredColor' dateFormat="MM/dd/yyyy"
              onChange={(date) => { setParentContactDtTm(date); setValue({ ...value, ['ParentContactDtTm']: date ? getShowingWithOutTime(date) : null }) }}
              selected={parentContactDtTm}
              isClearable={value?.ParentContactDtTm ? true : false}
              placeholderText={value?.ParentContactDtTm ? value?.ParentContactDtTm : 'Select...'}
              timeIntervals={1}
              maxDate={new Date()}
              showYearDropdown
              showMonthDropdown
              dropdownMode="select"
              autoComplete='Off'
            />
          </div>
          <div className="col-2 col-md-2 col-lg-2 mt-2 pt-2">
            <label htmlFor="" className='new-label'>Contacted By {errors.ContactByIDErrors !== 'true' ? (
              <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.ContactByIDErrors}</p>
            ) : null}</label>
          </div>
          <div className="col-4 col-md-4 col-lg-4 mt-2 ">
            <Select
              name='ContactByID'
              value={headOfAgency?.filter((obj) => obj.value === value?.ContactByID)}
              options={headOfAgency}
              styles={colourStyles}
              isClearable
              placeholder="Select..."
              onChange={(e) => { ChangeDropDown(e, 'ContactByID') }}
            />
          </div>
          <div className="col-2 col-md-2 col-lg-2 mt-2 pt-2">
            <label htmlFor="" className='new-label'>Parent Address</label>
          </div>
          <div className="col-4 col-md-4 col-lg-4 mt-2 ">
            <textarea name='ParentAddress' id="ParentAddress" value={value?.ParentAddress} onChange={handleChange} cols="30" rows='2' className="form-control " >
            </textarea>
          </div>
        </div>
      </div>
      <div className="btn-box text-right  mr-1 mb-2 mt-2">
        <button type="button" className="btn btn-sm btn-success mr-1 " onClick={() => { setStatusFalse(); }}>New</button>

        {
          status ?
            <button type="button" onClick={() => check_Validation_Error()} className="btn btn-sm btn-success mr-1">Update</button>
            :
            <button type="button" onClick={() => check_Validation_Error()} className="btn btn-sm btn-success mr-1">Save</button>
        }
      </div>
      <div className="col-12 mt-2">
        {/* {
          loder ? */}
        <DataTable
          dense
          columns={columns}
          data={juvenileData}
          highlightOnHover
          noDataComponent={"There are no data to display"}
          onRowClicked={(row) => {
            setClickedRow(row);
            set_Edit_Value(row);
          }}
          fixedHeaderScrollHeight='500px'
          conditionalRowStyles={conditionalRowStyles}
          fixedHeader
          persistTableHead={true}
          customStyles={tableCustomStyles}
        />
        {/* :
            <Loader />

        } */}
      </div>

      {/* <JuvenileAddUp  {...{ loginPinID, arrestID, loginAgencyID, arrestJuvenileID, status, setStatus, modal, setModal, get_Data_Juvenile, updateStatus }} /> */}
      <DeletePopUpModal func={DeleteJuvenile} />
    </>
  )
}

export default Juvenile