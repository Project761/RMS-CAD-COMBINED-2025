import React, { useCallback, useContext, useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import { Decrypt_Id_Name, filterPassedTime, getShowingDateText, getShowingMonthDateYear, tableCustomStyles } from '../../../../Common/Utility';
import { fetchPostData, AddDeleteUpadate, ScreenPermision } from '../../../../hooks/Api';
import DataTable from 'react-data-table-component';
import { toastifyError, toastifySuccess } from '../../../../Common/AlertMsg';
import DeletePopUpModal from '../../../../Common/DeleteModal';
import { AgencyContext } from '../../../../../Context/Agency/Index';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import { Editor } from 'react-draft-wysiwyg';
import { EditorState, ContentState, convertFromHTML } from 'draft-js';
import { Comman_changeArrayFormat } from '../../../../Common/ChangeArrayFormat';
import { convertToHTML } from 'draft-convert';
import { RequiredFieldIncident, Space_Allow_with_Trim, Space_Not_Allow } from '../../../Utility/Personnel/Validation';
import DatePicker from 'react-datepicker';
import Select from "react-select";
import Loader from '../../../../Common/Loader';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { get_LocalStoreData } from '../../../../../redux/actions/Agency';

const Narrative = (props) => {

  const { DecArrestId, DecIncID } = props
  const dispatch = useDispatch();
  const localStoreData = useSelector((state) => state.Agency.localStoreData);
  const uniqueId = sessionStorage.getItem('UniqueUserID') ? Decrypt_Id_Name(sessionStorage.getItem('UniqueUserID'), 'UForUniqueUserID') : '';
  const [clickedRow, setClickedRow] = useState(null);

  const { get_Arrest_Count, localStoreArray, get_LocalStorage, } = useContext(AgencyContext)
  const [narrativeData, setNarrativeData] = useState([])
  const [upDateCount, setUpDateCount] = useState(0)
  const [status, setStatus] = useState(false)
  const [modal, setModal] = useState(false);
  const [arrestNarrativeID, setArrestNarrativeID] = useState('')
  const [loder, setLoder] = useState(false)
  //screen permission 
  const [effectiveScreenPermission, setEffectiveScreenPermission] = useState()

  const [arrestID, setArrestID] = useState('');
  const [loginAgencyID, setLoginAgencyID] = useState('');
  const [loginPinID, setLoginPinID,] = useState('');
  const [editval, setEditval] = useState();
  const [narrativeDtTm, setNarrativeDtTm] = useState()
  const [headOfAgency, setHeadOfAgency] = useState([])
  const [narrativeTypeList, setNarrativeTypeList] = useState([])

  const [value, setValue] = useState({
    'CommentsDoc': '',
    'NarrativeComments': '',
    'NarrativeDtTm': '',
    'NarrativeTypeID': '',
    'ReportedByID': '',
    'ModifiedByUserFK': '',
    'CreatedByUserFK': '',
    'ArrestID': '',
    'ArrestNarrativeID': '',
  })


  useEffect(() => {
    if (!localStoreData?.AgencyID || !localStoreData?.PINID) {
      if (uniqueId) dispatch(get_LocalStoreData(uniqueId));
    }
  }, []);

  useEffect(() => {
    if (localStoreData) {
      setLoginPinID(parseInt(localStoreData?.PINID)); setLoginAgencyID(parseInt(localStoreData?.AgencyID));
      //   getScreenPermision(localStoreData?.AgencyID, localStoreData?.PINID);
    }
  }, [localStoreData]);

  useEffect(() => {
    if (loginPinID) {
      setValue({
        ...value,
        'CommentsDoc': '', 'NarrativeComments': '', 'NarrativeDtTm': '', 'NarrativeTypeID': '',
        'ReportedByID': loginPinID, 'ModifiedByUserFK': '', 'ArrestNarrativeID': '',
        'ArrestID': '', 'CreatedByUserFK': loginPinID,
      })
    }
  }, [loginPinID]);

  useEffect(() => {
    if (DecArrestId) {
      get_NarrativesData(DecArrestId); setArrestID(DecArrestId);
    }
  }, [DecArrestId]);

  const get_NarrativesData = (ArrestID) => {
    const val = {
      'ArrestID': ArrestID,
    }
    fetchPostData('ArrestNarrative/GetData_ArrestNarrative', val)
      .then(res => {
        if (res) {
          setNarrativeData(res); setLoder(true)
        } else {
          setNarrativeData([]); setLoder(true)
        }
      })
  }

  const getScreenPermision = (loginAgencyID, loginPinID) => {
    ScreenPermision("I032", loginAgencyID, loginPinID).then(res => {
      if (res) {
        setEffectiveScreenPermission(res)
      } else {
        setEffectiveScreenPermission()
      }
    });
  }

  const columns = [
    // {
    //   width: '120px',
    //   name: <p className='text-end' style={{ position: 'absolute', top: '7px', }}>Action</p>,
    //   cell: row =>
    //     <div style={{ position: 'absolute', top: 4, left: 20 }}>
    //       {
    //         effectiveScreenPermission ? effectiveScreenPermission[0]?.Changeok ?
    //           <Link to={''} onClick={(e) => editNarratives(e, row)} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#NarrativeModal" >
    //             <i className="fa fa-edit"></i>
    //           </Link>
    //           : <></>
    //           : <Link to={''} onClick={(e) => editNarratives(e, row)} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#NarrativeModal" >
    //             <i className="fa fa-edit"></i>
    //           </Link>
    //       }

    //     </div>

    // },
    {
      name: 'Date',
      selector: (row) => getShowingDateText(row.NarrativeDtTm),
      sortable: true
    },
    {
      name: 'Narrative',
      selector: (row) => <>{row?.NarrativeComments ? row?.NarrativeComments.substring(0, 50) : ''}{row?.NarrativeComments?.length > 40 ? '  . . .' : null} </>,
      sortable: true
    },
    {
      name: 'Reported By',
      selector: (row) => row.ReportedBy_Description,
      sortable: true
    },
    {
      name: 'Type',
      selector: (row) => row.NarrativeDescription,
      sortable: true
    },
    {
      name: <p className='text-end' style={{ position: 'absolute', top: '7px', right: '0px' }}>Delete</p>,
      cell: row =>
        <div style={{ position: 'absolute', top: 4, right: 5 }}>

          {
            effectiveScreenPermission ? effectiveScreenPermission[0]?.DeleteOK ?
              <span to={`#`} onClick={(e) => setArrestNarrativeID(row.ArrestNarrativeID)} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#DeleteModal">
                <i className="fa fa-trash"></i>
              </span>
              : <></>
              : <span to={`#`} onClick={(e) => setArrestNarrativeID(row.ArrestNarrativeID)} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#DeleteModal">
                <i className="fa fa-trash"></i>
              </span>
          }
        </div>

    }
  ]




  const [errors, setErrors] = useState({
    'NarrativeDtTmError': '', 'ArrestNarrativeIDError': '', 'NarrativeCommentsError': '', 'ReportedByIDError': '',
  })



  const [editorState, setEditorState] = useState(
    () => EditorState.createEmpty(),
  );

  useEffect(() => {
    if (arrestNarrativeID && status) {
      GetSingleData(arrestNarrativeID)
    }
  }, [upDateCount, arrestNarrativeID])

  const GetSingleData = (arrestNarrativeID) => {
    const val = { 'ArrestNarrativeID': arrestNarrativeID }
    fetchPostData('ArrestNarrative/GetSingleData_ArrestNarrative', val)
      .then((res) => {
        if (res) setEditval(res)
        else setEditval()
      })
  }

  useEffect(() => {
    if (status) {
      setValue({
        ...value,
        "ArrestNarrativeID": arrestNarrativeID,
        'NarrativeDtTm': editval[0].NarrativeDtTm ? getShowingDateText(editval[0].NarrativeDtTm) : '',
        'NarrativeTypeID': editval[0].NarrativeTypeID,
        'ReportedByID': editval[0].ReportedByID,
        'CreatedByUserFK': editval[0].CreatedByUserFK,
        'NarrativeComments': editval[0].NarrativeComments,
        'ModifiedByUserFK': loginPinID,
        'CommentsDoc': editval[0].CommentsDoc,
      })
      setEditorState(EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(editval[0].CommentsDoc))));
    } else {
      setValue({
        ...value,
        'NarrativeComments': '', 'CommentsDoc': '', 'ModifiedByUserFK': '', 'ArrestNarrativeID': '',
        'NarrativeDtTm': '', 'NarrativeTypeID': '', 'ReportedByID': loginPinID, 'CreatedByUserFK': loginPinID,
      });
      setEditorState(() => EditorState.createEmpty(),);

    }
  }, [editval])

  // Get Head of Agency
  useEffect(() => {
    if (loginAgencyID) {
      Get_Officer_Name(loginAgencyID);
      get_Narrative_Type(loginAgencyID);
    }
  }, [loginAgencyID])

  const Get_Officer_Name = (loginAgencyID) => {
    const val = {
      AgencyID: loginAgencyID
    }
    fetchPostData('DropDown/GetData_HeadOfAgency', val)
      .then(res => {
        if (res) {
          setHeadOfAgency(Comman_changeArrayFormat(res, 'PINID', 'HeadOfAgency'))
        } else setHeadOfAgency([])
      })
  };

  const get_Narrative_Type = (loginAgencyID) => {
    const val = {
      AgencyID: loginAgencyID
    }
    fetchPostData('NarrativeType/GetDataDropDown_NarrativeType', val)
      .then((res) => {
        if (res) { setNarrativeTypeList(Comman_changeArrayFormat(res, 'NarrativeTypeID', 'Description')) }
        else { setNarrativeTypeList([]) }
      })
  }

  const escFunction = useCallback((event) => {
    if (event.key === "Escape") {
      reset()
    }
  }, []);

  useEffect(() => {
    document.addEventListener("keydown", escFunction, false);
    return () => {
      document.removeEventListener("keydown", escFunction, false);
    };
  }, [escFunction]);

  const ChangeDropDown = (e, name) => {
    if (e) {
      setValue({
        ...value, [name]: e.value
      })
    } else {
      setValue({
        ...value, [name]: null
      })
    }
  }

  const handleEditorChange = (state) => {
    setEditorState(state);
    convertContentToHTML();
  }

  const convertContentToHTML = () => {
    let currentContentAsHTML = convertToHTML(editorState.getCurrentContent());
    setValue({ ...value, 'CommentsDoc': currentContentAsHTML })
  }

  const getValueNarrative = (e) => {
    setValue({
      ...value,
      ['NarrativeComments']: e.blocks[0].text
    })
  }

  const reset = (e) => {
    setValue({
      ...value, 'NarrativeTypeID': '', 'NarrativeComments': '', 'NarrativeDtTm': '', 'CommentsDoc': '', 'ModifiedByUserFK': '', 'ArrestNarrativeID': '',
      'headOfAgencyName': '', 'ReportedByID': loginPinID,
    });
    setErrors({
      ...errors,
      'ReportedByPinError': '', 'NarrativeDtTmError': '', 'ArrestNarrativeIDError': '', 'NarrativeCommentsError': '', 'ReportedByIDError': '',
    });
    setNarrativeDtTm('');
    setEditorState(() => EditorState.createEmpty(),);
  }

  const check_Validation_Error = (e) => {
    if (RequiredFieldIncident(value.NarrativeDtTm)) {
      setErrors(prevValues => { return { ...prevValues, ['NarrativeDtTmError']: RequiredFieldIncident(value.NarrativeDtTm) } })
    }
    if (RequiredFieldIncident(value.NarrativeTypeID)) {
      setErrors(prevValues => { return { ...prevValues, ['ArrestNarrativeIDError']: RequiredFieldIncident(value.NarrativeTypeID) } })
    }
    if (Space_Not_Allow(value.NarrativeComments)) {
      setErrors(prevValues => { return { ...prevValues, ['NarrativeCommentsError']: Space_Not_Allow(value.NarrativeComments) } })
    }
    if (RequiredFieldIncident(value.ReportedByID)) {
      setErrors(prevValues => { return { ...prevValues, ['ReportedByIDError']: RequiredFieldIncident(value.ReportedByID) } })
    }
  }

  // Check All Field Format is True Then Submit 
  const { NarrativeDtTmError, ArrestNarrativeIDError, NarrativeCommentsError, ReportedByIDError } = errors

  useEffect(() => {
    if (NarrativeDtTmError === 'true' && ArrestNarrativeIDError === 'true' && NarrativeCommentsError === 'true' && ReportedByIDError === 'true') {
      if (status) { updateNarrative() }
      else { submit() }
    }
  }, [NarrativeDtTmError, ArrestNarrativeIDError, NarrativeCommentsError, ReportedByIDError])



  const submit = () => {
    const result = narrativeData?.find(item => {
      if (item.NarrativeComments) {
        if (item.NarrativeComments.toLowerCase() === value.NarrativeComments.toLowerCase()) {
          return item.NarrativeComments.toLowerCase() === value.NarrativeComments.toLowerCase()
        } else return item.NarrativeComments.toLowerCase() === value.NarrativeComments.toLowerCase()
      }
    }
    );
    if (result) {
      toastifyError('Comments Already Exists')
      setErrors({ ...errors, ['NarrativeCommentsError']: '' })
    } else {

      const { CommentsDoc, NarrativeComments, NarrativeDtTm, NarrativeTypeID, ReportedByID, ModifiedByUserFK,
        ArrestNarrativeID, ArrestID, CreatedByUserFK } = value;

      const val = {
        'CommentsDoc': CommentsDoc, 'NarrativeComments': NarrativeComments, 'NarrativeDtTm': NarrativeDtTm, 'NarrativeTypeID': NarrativeTypeID, 'ReportedByID': ReportedByID,
        'ArrestNarrativeID': ArrestNarrativeID, 'ArrestID': DecArrestId, 'CreatedByUserFK': loginPinID, 'ModifiedByUserFK': loginPinID,
      }
      // console.log(val)
      AddDeleteUpadate('ArrestNarrative/Insert_Narrative', val)
        .then((res) => {
          const parsedData = JSON.parse(res.data);
          const message = parsedData.Table[0].Message;
          toastifySuccess(message);
          get_Arrest_Count(arrestID)
          setModal(false)
          get_NarrativesData(arrestID);
          reset();
          setErrors({
            ['NarrativeDtTmError']: '',
          })
        })
    }
  }

  const updateNarrative = (e) => {
    const result = narrativeData?.find(item => {
      if (item.NarrativeComments) {
        if (item.ArrestNarrativeID != value.ArrestNarrativeID) {
          if (item.NarrativeComments.toLowerCase() === value.NarrativeComments.toLowerCase()) {
            return item.NarrativeComments.toLowerCase() === value.NarrativeComments.toLowerCase()
          } else return item.NarrativeComments.toLowerCase() === value.NarrativeComments.toLowerCase()
        }
      }
    }
    );
    if (result) {
      toastifyError('Code Already Exists')
      setErrors({ ...errors, ['NarrativeCommentsError']: '' })

    } else {
      AddDeleteUpadate('ArrestNarrative/Update_ArrestNarrative', value)
        .then((res) => {
          const parsedData = JSON.parse(res.data);
          const message = parsedData.Table[0].Message;
          toastifySuccess(message);
          get_NarrativesData(arrestID);
          setModal(false)
          reset();
          setErrors({
            ['NarrativeDtTmError']: '',
          })
        })
    }
  }

  const DeleteNarratives = () => {
    const val = {
      'ArrestNarrativeID': arrestNarrativeID,
      'DeletedByUserFK': loginPinID,
    }
    AddDeleteUpadate('ArrestNarrative/Delete_ArrestNarrative', val).then((res) => {
      if (res.success) {
        const parsedData = JSON.parse(res.data);
        const message = parsedData.Table[0].Message;
        toastifySuccess(message);
        get_Arrest_Count(arrestID); reset()
        get_NarrativesData(arrestID); setStatus(false);
      } else { console.log("Somthing Wrong"); }
    })
  }

  const startRef = React.useRef();

  const onKeyDown = (e) => {
    if (e.keyCode === 9 || e.which === 9) {
      startRef.current.setOpen(false);
    }
  };

  const closeModal = () => {
    reset();
    setModal(false);
  }

  const colourStyles = {
    control: (styles) => ({
      ...styles,
      backgroundColor: "#fce9bf",
      height: 20,
      minHeight: 30,
      fontSize: 14,
      margintop: 2,
      boxShadow: 0,
    }),
  }
  const setStatusFalse = (e) => {
    setClickedRow(null);
    setStatus(false);
    setModal(true);
    reset();
  }
  const editNarratives = (row) => {
    get_Arrest_Count(row.ArrestID)
    setArrestNarrativeID(row.ArrestNarrativeID);
    setUpDateCount(upDateCount + 1);
    setStatus(true)
    setModal(true); setErrors('')
  }

  const conditionalRowStyles = [
    {
      when: row => row === clickedRow,
      style: {
        backgroundColor: '#001f3fbd',
        color: 'white',
        cursor: 'pointer',
      },
    },
  ];
  return (
    <>
      <div className="row mt-1">
        <div className="col-12 col-md-12 col-lg-12 px-0 pl-0">
          <Editor
            editorState={editorState}
            onEditorStateChange={handleEditorChange}
            wrapperClassName="wrapper-class"
            editorClassName="editor-class"
            toolbarClassName="toolbar-class"
            onChange={getValueNarrative}
            editorStyle={{ height: '15vh' }}
            toolbar={{
              options: ['inline', 'blockType', 'fontFamily', 'list', 'history'],
              inline: {
                inDropdown: false,
                className: undefined,
                component: undefined,
                dropdownClassName: undefined,
                options: ['bold', 'italic', 'underline', 'monospace',],
              },
            }}
          />
          {errors.NarrativeCommentsError !== 'true' ? (
            <span style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.NarrativeCommentsError}</span>
          ) : null}
        </div>
      </div>
      <div className="col-12">
        <div className="row">
          <div className="col-6">
            <div className="row">
              <div className="col-4 col-md-4 col-lg-4 mt-3">
                <span className='new-label'>
                  Reported By {errors.ReportedByIDError !== 'true' ? (
                    <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.ReportedByIDError}</p>
                  ) : null}
                </span>
              </div>
              <div className="col-7 col-md-7 col-lg-7 mt-2 ">
                <Select
                  name='ReportedByID'
                  isClearable
                  styles={colourStyles}
                  value={headOfAgency?.filter((obj) => obj.value === value?.ReportedByID)}
                  options={headOfAgency}
                  onChange={(e) => ChangeDropDown(e, 'ReportedByID')}
                  placeholder="Select.."
                  menuPlacement="top"
                />

              </div>
              <div className="col-4 col-md-4 col-lg-4 mt-2 pt-2">
                <label htmlFor="" className='new-label'>Date/Time{errors.NarrativeDtTmError !== 'true' ? (
                  <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.NarrativeDtTmError}</p>
                ) : null}</label>
              </div>
              <div className="col-7 col-md-7 col-lg-7 mt-2 ">
                <DatePicker
                  ref={startRef}
                  onKeyDown={onKeyDown}
                  dateFormat="MM/dd/yyyy HH:mm"
                  timeInputLabel
                  isClearable={value?.NarrativeDtTm ? true : false}
                  className='requiredColor'
                  name='NarrativeDtTm'
                  onChange={(date) => { setNarrativeDtTm(date); setValue({ ...value, ['NarrativeDtTm']: date ? getShowingMonthDateYear(date) : null }) }}
                  selected={narrativeDtTm}
                  placeholderText={value.NarrativeDtTm ? value.NarrativeDtTm : 'Select...'}
                  showTimeSelect
                  filterTime={filterPassedTime}
                  timeIntervals={1}
                  timeCaption="Time"
                  dropdownMode="select"
                  popperPlacement="top-end"
                  maxDate={new Date()}

                />
              </div>
            </div>
          </div>
          <div className="col-6">
            <div className="row">
              <div className="col-4 col-md-4 col-lg-4 mt-2 pt-2">
                <label htmlFor="" className='new-label'>Narrative Type/Report Type {errors.ArrestNarrativeIDError !== 'true' ? (
                  <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.ArrestNarrativeIDError}</p>
                ) : null}</label>
              </div>
              <div className="col-7 col-md-7 col-lg-7 mt-2 ">
                <Select
                  name='NarrativeTypeID'
                  isClearable
                  styles={colourStyles}
                  value={narrativeTypeList?.filter((obj) => obj.value === value?.NarrativeTypeID)}
                  options={narrativeTypeList}
                  onChange={(e) => ChangeDropDown(e, 'NarrativeTypeID')}
                  placeholder="Select.."
                  menuPlacement="top"
                />

              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="col-12 text-right mt-3 ">
        <button type="button" className="btn btn-sm btn-success mr-1 " onClick={() => { setStatusFalse(); }}>New</button>
        {
          status ?
            <button type="button" onClick={() => check_Validation_Error()} className="btn btn-sm btn-success pl-2">Update</button>
            :
            <button type="button" onClick={() => check_Validation_Error()} className="btn btn-sm btn-success pl-2">Save</button>
        }
      </div>
      <div className="col-12 mt-2">
        {/* {
          loder ? */}
        <DataTable
          dense
          columns={columns}
          data={effectiveScreenPermission ? effectiveScreenPermission[0]?.DisplayOK ? narrativeData : '' : narrativeData}
          selectableRowsHighlight
          highlightOnHover
          onRowClicked={(row) => {
            setClickedRow(row);
            editNarratives(row);
          }}
          fixedHeaderScrollHeight='250px'
          conditionalRowStyles={conditionalRowStyles}
          fixedHeader
          persistTableHead={true}
          customStyles={tableCustomStyles}
          noDataComponent={effectiveScreenPermission ? effectiveScreenPermission[0]?.DisplayOK ? "There are no data to display" : "You don’t have permission to view data" : 'There are no data to display'}
        />
        {/* :
            <Loader />
        } */}
      </div>
      <DeletePopUpModal func={DeleteNarratives} />

    </>
  )
}
export default Narrative;