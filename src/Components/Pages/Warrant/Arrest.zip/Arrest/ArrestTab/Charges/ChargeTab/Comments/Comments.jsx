import React, { useCallback, useContext, useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import { EditorState, ContentState, convertFromHTML } from 'draft-js';
import { convertToHTML } from 'draft-convert';
import Select from "react-select";
import { toastifyError, toastifySuccess } from '../../../../../../Common/AlertMsg';
import DeletePopUpModal from '../../../../../../Common/DeleteModal';
import { AgencyContext } from '../../../../../../../Context/Agency/Index';
import { Comman_changeArrayFormat } from '../../../../../../Common/ChangeArrayFormat';
import { AddDeleteUpadate, fetchPostData } from '../../../../../../hooks/Api';
import { RequiredFieldIncident } from '../../../../../Utility/Personnel/Validation';
import { Decrypt_Id_Name, tableCustomStyles } from '../../../../../../Common/Utility';
import { useDispatch, useSelector } from 'react-redux';
import { get_LocalStoreData } from '../../../../../../../redux/actions/Agency';

const Comments = (props) => {

    const { DecChargeId } = props

    const dispatch = useDispatch();
    const localStoreData = useSelector((state) => state.Agency.localStoreData);
    const uniqueId = sessionStorage.getItem('UniqueUserID') ? Decrypt_Id_Name(sessionStorage.getItem('UniqueUserID'), 'UForUniqueUserID') : '';

    const { get_ArrestCharge_Count } = useContext(AgencyContext);
    const [commentData, setCommentData] = useState([])
    const [ArrestChargeCommentsID, setArrestChargeCommentsID] = useState('')
    const [upDateCount, setUpDateCount] = useState(0)
    const [status, setStatus] = useState(false)
    const [modal, setModal] = useState(false);
    const [loder, setLoder] = useState(false)
    const [effectiveScreenPermission, setEffectiveScreenPermission] = useState();
    const [ChargeID, setChargeID] = useState('');
    const [loginAgencyID, setLoginAgencyID] = useState('');
    const [loginPinID, setLoginPinID,] = useState('');
    const [editval, setEditval] = useState();
    const [clickedRow, setClickedRow] = useState(null);
    const [headOfAgency, setHeadOfAgency] = useState([])

    const [value, setValue] = useState({
        'CommentsDoc': '', 'ChargeID': '', 'Comments': '', 'CreatedByUserFK': '', 'ModifiedByUserFK': '', 'OfficerID': '', 'ArrestChargeCommentsID': "",

    })

    useEffect(() => {
        if (!localStoreData?.AgencyID || !localStoreData?.PINID) {
            if (uniqueId) dispatch(get_LocalStoreData(uniqueId));
        }
    }, []);

    useEffect(() => {
        if (localStoreData) {
            setLoginPinID(parseInt(localStoreData?.PINID)); setLoginAgencyID(parseInt(localStoreData?.AgencyID)); get_CommentsData(DecChargeId);
        }
    }, [localStoreData]);

    useEffect(() => {
        if (loginPinID) {
            setValue({
                ...value,
                'CreatedByUserFK': loginPinID, 'OfficerID': loginPinID, 'ArrestChargeCommentsID': "",
                'CommentsDoc': '', 'ChargeID': DecChargeId, 'Comments': '', 'ModifiedByUserFK': '',
            })
        }
    }, [loginPinID]);

    useEffect(() => {
        if (DecChargeId) {
            get_CommentsData(DecChargeId); setChargeID(DecChargeId);
        }
    }, [DecChargeId]);


    const [errors, setErrors] = useState({
        'CommentsError': '', 'OfficerIDError': '',
    })

    const [editorState, setEditorState] = useState(
        () => EditorState.createEmpty(),
    );

    useEffect(() => {
        if (loginAgencyID) {
            Get_Officer_Name(loginAgencyID);
        }
    }, [loginAgencyID])

    useEffect(() => {
        if (ArrestChargeCommentsID && status) {
            GetSingleData(ArrestChargeCommentsID)
        }
    }, [upDateCount, ArrestChargeCommentsID])

    const GetSingleData = (ArrestChargeCommentsID) => {
        const val = { 'ArrestChargeCommentsID': ArrestChargeCommentsID }
        fetchPostData('ArrestChargeComments/GetSingleData_ArrestChargeComments', val)
            .then((res) => {
                if (res) { setEditval(res) }
                else { setEditval([]) }
            })
    }

    useEffect(() => {
        if (status) {
            setValue({
                ...value,
                'ArrestChargeCommentsID': ArrestChargeCommentsID, 'OfficerID': editval[0].OfficerID, 'Comments': editval[0].Comments,
                'ModifiedByUserFK': loginPinID, 'CommentsDoc': editval[0].CommentsDoc,
            })
            setEditorState(EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(editval[0].CommentsDoc))));
        } else {
            setValue({
                ...value,
                'CommentsDoc': '', 'ChargeID': '', 'Comments': '', 'CreatedByUserFK': loginPinID, 'ModifiedByUserFK': '', 'OfficerID': loginPinID, 'ArrestChargeCommentsID': "",
            });
            setEditorState(() => EditorState.createEmpty(),);
        }
    }, [editval])

    const reset = (e) => {
        setValue({
            ...value,
            'CommentsDoc': '', 'ChargeID': '', 'Comments': '', 'CreatedByUserFK': loginPinID, 'ModifiedByUserFK': '', 'OfficerID': loginPinID, 'ArrestChargeCommentsID': "",
        });
        setErrors({
            ...errors,
            'CommentsError': '', 'OfficerIDError': '',
        });
        setEditorState(() => EditorState.createEmpty(),);
    }

    const check_Validation_Error = (e) => {
        if (RequiredFieldIncident(value.Comments)) {
            setErrors(prevValues => { return { ...prevValues, ['CommentsError']: RequiredFieldIncident(value.Comments) } })
        }
        if (RequiredFieldIncident(value.OfficerID)) {
            setErrors(prevValues => { return { ...prevValues, ['OfficerIDError']: RequiredFieldIncident(value.OfficerID) } })
        }
    }

    const { CommentsError, OfficerIDError } = errors

    useEffect(() => {
        if (CommentsError === 'true' && OfficerIDError === 'true') {
            if (status) { updateComments() }
            else { submit() }
        }
    }, [CommentsError, OfficerIDError])

    // Get Head of Agency
    const Get_Officer_Name = (loginAgencyID) => {
        const val = { AgencyID: loginAgencyID }
        fetchPostData('DropDown/GetData_HeadOfAgency', val)
            .then(res => {
                if (res) {
                    setHeadOfAgency(Comman_changeArrayFormat(res, 'PINID', 'HeadOfAgency'))
                } else { setHeadOfAgency([]) }
            })
    };

    const escFunction = useCallback((event) => {
        if (event.key === "Escape") { reset() }
    }, []);

    useEffect(() => {
        document.addEventListener("keydown", escFunction, false);
        return () => {
            document.removeEventListener("keydown", escFunction, false);
        };
    }, [escFunction]);

    const ChangeDropDown = (e, name) => {
        if (e) {
            setValue({ ...value, [name]: e.value })
        } else {
            setValue({ ...value, [name]: null })
        }
    }

    const handleEditorChange = (state) => {
        setEditorState(state); convertContentToHTML();
    }

    const convertContentToHTML = () => {
        let currentContentAsHTML = convertToHTML(editorState.getCurrentContent());
        setValue({ ...value, 'CommentsDoc': currentContentAsHTML })
    }

    const getValueNarrative = (e) => {
        setValue({ ...value, ['Comments']: e.blocks[0].text })
    }

    const submit = () => {
        const result = commentData?.find(item => {
            if (item.Comments) {
                if (item.Comments.toLowerCase() === value.Comments.toLowerCase()) {
                    return item.Comments.toLowerCase() === value.Comments.toLowerCase()
                } else return item.Comments.toLowerCase() === value.Comments.toLowerCase()
            }
        });
        if (result) {
            toastifyError('Comments Already Exists')
            setErrors({ ...errors, ['CommentsError']: '', })
        } else {
            const { CommentsDoc, ChargeID, Comments, CreatedByUserFK,
                OfficerID, AdminOfficer, ArrestChargeCommentsID, ModifiedByUserFK,
            } = value;
            const val = {
                'CommentsDoc': CommentsDoc, 'ChargeID': DecChargeId, 'Comments': Comments, 'CreatedByUserFK': loginPinID,
                'OfficerID': OfficerID, 'ArrestChargeCommentsID': ArrestChargeCommentsID, 'ModifiedByUserFK': ModifiedByUserFK,
            }
            AddDeleteUpadate('ArrestChargeComments/Insert_ArrestChargeComments', val)
                .then((res) => {
                    toastifySuccess(res.Message); get_ArrestCharge_Count(ChargeID); setModal(false)
                    get_CommentsData(ChargeID); reset();
                })
        }
    }

    const updateComments = (e) => {
        const result = commentData?.find(item => {
            if (item.Comments) {
                if (item.ArrestChargeCommentsID != value.ArrestChargeCommentsID) {
                    if (item.Comments.toLowerCase() === value.Comments.toLowerCase()) {
                        return item.Comments.toLowerCase() === value.Comments.toLowerCase()
                    } else return item.Comments.toLowerCase() === value.Comments.toLowerCase()
                }
            }
        });
        if (result) {
            toastifyError('Code Already Exists'); setErrors({ ...errors, ['NarrativeCommentsError']: '' })
        } else {
            AddDeleteUpadate('ArrestChargeComments/Update_ArrestChargeComments', value)
                .then((res) => {
                    toastifySuccess(res.Message); get_CommentsData(ChargeID); setModal(false); reset();
                })
        }
    }


    const colourStyles = {
        control: (styles) => ({
            ...styles,
            backgroundColor: "#fce9bf",
            height: 20,
            minHeight: 35,
            fontSize: 14,
            margintop: 2,
            boxShadow: 0,
        }),
    }

    const get_CommentsData = () => {
        const val = { 'ChargeID': ChargeID }
        fetchPostData('ArrestChargeComments/GetData_ArrestChargeComments', val)
            .then(res => {
                if (res) {
                    setCommentData(res); setLoder(true)
                } else {
                    setCommentData([]); setLoder(true)
                }
            })
    }


    const getScreenPermision = (loginAgencyID, loginPinID) => {
        // ScreenPermision("I033", loginAgencyID, loginPinID).then(res => {
        //     if (res) {
        //         setEffectiveScreenPermission(res)
        //     } else {
        //         setEffectiveScreenPermission()
        //     }
        // });
    }

    const columns = [
        {
            name: 'Comments',
            selector: (row) => <>{row?.Comments ? row?.Comments.substring(0, 60) : ''}{row?.Comments?.length > 40 ? '  . . .' : null} </>,
            sortable: true
        },

        {
            name: <p className='text-end' style={{ position: 'absolute', top: '7px', right: 10 }}>Delete</p>,
            cell: row =>
                <div style={{ position: 'absolute', top: 4, right: 10 }}>
                    <span to={`#`} onClick={(e) => setArrestChargeCommentsID(row.ArrestChargeCommentsID)} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#DeleteModal">
                        <i className="fa fa-trash"></i>
                    </span>
                </div>
        }
    ]

    const editComments = (val) => {
        get_ArrestCharge_Count(val.ChargeID); setArrestChargeCommentsID(val.ArrestChargeCommentsID);
        setUpDateCount(upDateCount + 1); setStatus(true); setErrors(''); setModal(true);
    }

    const setStatusFalse = (e) => {
        setClickedRow(null); setStatus(false); setModal(true); reset();
    }

    const DeleteComments = () => {
        const val = {
            'ArrestChargeCommentsID': ArrestChargeCommentsID, 'DeletedByUserFK': loginPinID,
        }
        AddDeleteUpadate('ArrestChargeComments/Delete_ArrestChargeComments', val).then((res) => {
            if (res.success) {
                const parsedData = JSON.parse(res.data);
                const message = parsedData.Table[0].Message;
                toastifySuccess(message); reset(); get_ArrestCharge_Count(ChargeID); get_CommentsData(ChargeID); setStatus(false);
            } else console.log("Somthing Wrong");
        })
    }

    const conditionalRowStyles = [
        {
            when: row => row === clickedRow,
            style: {
                backgroundColor: '#001f3fbd', color: 'white', cursor: 'pointer',
            },
        },
    ];
    return (
        <>

            <div className="row mt-1">
                <div className="col-12 col-md-12 col-lg-12 px-0 pl-0">
                    <Editor
                        editorState={editorState}
                        onEditorStateChange={handleEditorChange}
                        wrapperClassName="wrapper-class"
                        editorClassName="editor-class"
                        toolbarClassName="toolbar-class"
                        onChange={getValueNarrative}
                        editorStyle={{ height: '15vh' }}
                        toolbar={{
                            options: ['inline', 'blockType', 'fontFamily', 'list', 'history'],
                            inline: {
                                inDropdown: false,
                                className: undefined,
                                component: undefined,
                                dropdownClassName: undefined,
                                options: ['bold', 'italic', 'underline', 'monospace',],
                            },
                        }}
                    />
                    {errors.CommentsError !== 'true' ? (
                        <span style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.CommentsError}</span>
                    ) : null}
                </div>
            </div>
            <div className="col-12">
                <div className="row">
                    <div className="col-2 col-md-2 col-lg-1 mt-2 pt-2">
                        <label htmlFor="" className='new-label'>Reported By{errors.OfficerIDError !== 'true' ? (
                            <p style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.OfficerIDError}</p>
                        ) : null}</label>
                    </div>
                    <div className="col-4 col-md-4 col-lg-4 mt-2 ">
                        <Select
                            name='OfficerID'
                            isClearable
                            styles={colourStyles}
                            value={headOfAgency?.filter((obj) => obj.value === value?.OfficerID)}
                            options={headOfAgency}
                            onChange={(e) => ChangeDropDown(e, 'OfficerID')}
                            placeholder="Select.."
                            menuPlacement="top"
                        />
                    </div>
                    <div className="col-12 col-md-6 col-lg-7 text-right mt-2 pt-1">
                        <button type="button" className="btn btn-sm btn-success mr-1 " onClick={() => { setStatusFalse(); }}>New</button>
                        {
                            status ?
                                <button type="button" onClick={() => check_Validation_Error()} className="btn btn-sm btn-success pl-2">Update</button>
                                :
                                <button type="button" onClick={(e) => { check_Validation_Error(); }} className="btn btn-sm btn-success pl-2">Save</button>
                        }
                    </div>
                </div>
            </div>
            <div className="col-12 mt-3">
                {/* {
          loder ? */}
                <DataTable
                    dense
                    columns={columns}
                    data={effectiveScreenPermission ? effectiveScreenPermission[0]?.DisplayOK ? commentData : '' : commentData}
                    selectableRowsHighlight
                    highlightOnHover
                    pagination
                    customStyles={tableCustomStyles}
                    onRowClicked={(row) => {
                        setClickedRow(row);
                        editComments(row);
                    }}
                    persistTableHead={true}
                    conditionalRowStyles={conditionalRowStyles}
                    noDataComponent={effectiveScreenPermission ? effectiveScreenPermission[0]?.DisplayOK ? "There are no data to display" : "You don’t have permission to view data" : 'There are no data to display'}
                />
                {/* :/ */}
                {/* <Loader /> */}
            </div>
            <DeletePopUpModal func={DeleteComments} />
        </>
    )
}
export default Comments;