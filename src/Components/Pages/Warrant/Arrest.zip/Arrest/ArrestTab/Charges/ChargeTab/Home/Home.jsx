import React, { useState, useEffect, useContext } from 'react'
import Select from "react-select";
import { Decrypt_Id_Name, base64ToString, stringToBase64, tableCustomStyles } from '../../../../../../Common/Utility';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { AddDeleteUpadate, fetchPostData } from '../../../../../../hooks/Api';
import { Comman_changeArrayFormat, threeColArrayWithCode } from '../../../../../../Common/ChangeArrayFormat';
import { toastifySuccess } from '../../../../../../Common/AlertMsg';
import { AgencyContext } from '../../../../../../../Context/Agency/Index';
import { RequiredFieldIncident } from '../../../../../Utility/Personnel/Validation';
import DataTable from 'react-data-table-component';
import DeletePopUpModal from '../../../../../../Common/DeleteModal';
import IdentifyFieldColor from '../../../../../../Common/IdentifyFieldColor';
import { useDispatch, useSelector } from 'react-redux';
import { get_LocalStoreData } from '../../../../../../../redux/actions/Agency';
import ListModal from '../../../../../Utility/ListManagementModel/ListModal';

const Home = (props) => {

  const { setStatus } = props

  const useQuery = () => {
    const params = new URLSearchParams(useLocation().search);
    return {
      get: (param) => params.get(param)
    };
  };

  let DecArrestId = 0, DecChargeId = 0, DecIncID = 0
  const query = useQuery();
  var IncID = query?.get("IncId");
  var ArrestId = query?.get("ArrestId");
  var IncNo = query?.get("IncNo");
  var IncSta = query?.get("IncSta");
  var ChargeId = query?.get('ChargeId');
  var ChargeSta = query?.get('ChargeSta');
  var ArrNo = query?.get('ArrNo');
  var Name = query?.get("Name");

  if (!IncID) IncID = 0;
  else DecIncID = parseInt(base64ToString(IncID));
  if (!ChargeId) ChargeId = 0;
  else DecChargeId = parseInt(base64ToString(ChargeId));
  if (!ArrestId) ArrestId = 0;
  else DecArrestId = parseInt(base64ToString(ArrestId));

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const localStoreData = useSelector((state) => state.Agency.localStoreData);
  const uniqueId = sessionStorage.getItem('UniqueUserID') ? Decrypt_Id_Name(sessionStorage.getItem('UniqueUserID'), 'UForUniqueUserID') : '';

  const { get_Arrest_Count, get_Incident_Count, arrestChargeData, ArresteName, setArrestName, get_Data_Arrest_Charge, get_ArrestCharge_Count, setChangesStatus, incidentNumber, updateCount, setUpdateCount } = useContext(AgencyContext);

  const [clickedRow, setClickedRow] = useState(null);
  const [chargeCodeDrp, setChargeCodeDrp] = useState([]);
  const [nibrsDrpData, setNibrsDrpData] = useState([]);
  const [ucrclearDrp, setUcrClearDrp] = useState([]);
  const [Editval, setEditval] = useState();
  const [ArrestNumber, setArrestNumber] = useState('')
  const [ArrestID, setArrestID] = useState('')
  const [ChargeID, setChargeID] = useState();
  const [MainIncidentID, setMainIncidentID] = useState('');
  const [LoginAgencyID, setLoginAgencyID] = useState('');
  const [LoginPinID, setLoginPinID,] = useState('');
  const [openPage, setOpenPage] = useState('');

  const [value, setValue] = useState({
    'NameID': '', 'ArrestID': '', 'ArrestNumber': '', 'IncidentID': '', 'CreatedByUserFK': '',
    'Count': '', 'ChargeCodeID': '', 'NIBRSID': '', 'UCRClearID': '', 'ChargeID': '',
    'ModifiedByUserFK': '', 'Name': ArresteName,
  });

  const [errors, setErrors] = useState({
    'NIBRSIDError': '', 'ChargeCodeIDError': '',
  })
  useEffect(() => {
    if (DecArrestId !== null && !isNaN(DecArrestId)) {
      setArrestID(DecArrestId.toString());
    }
  }, [DecArrestId]);

  useEffect(() => {
    if (ArrestID !== '') {
      get_Data_Arrest_Charge(ArrestID);

    }
  }, [ArrestID]);

  useEffect(() => {
    if (!localStoreData?.AgencyID || !localStoreData?.PINID) {
      if (uniqueId) dispatch(get_LocalStoreData(uniqueId)); get_Data_Arrest_Charge(DecArrestId); get_Incident_Count(DecIncID);
    }
  }, []);

  useEffect(() => {
    if (localStoreData) {
      setLoginAgencyID(localStoreData?.AgencyID); setLoginPinID(localStoreData?.PINID);
      get_NIBRS_Drp_Data(localStoreData?.AgencyID); get_UcrClear_Drp_Data(localStoreData?.AgencyID);
    }
  }, [localStoreData]);

  useEffect(() => {
    if (DecArrestId) {
      setMainIncidentID(DecIncID);
    }
  }, [DecArrestId]);

  useEffect(() => {
    if (LoginAgencyID) {
      setValue({
        ...value,
        'IncidentID': DecIncID, 'ArrestID': DecArrestId, 'ChargeID': DecChargeId, 'CreatedByUserFK': LoginPinID, 'AgencyID': LoginAgencyID, 'Name': ArresteName, 'ArrestNumber': ArrestNumber,
      })

    }
  }, [LoginAgencyID]);

  useEffect(() => {
    if (DecChargeId) {
      setChargeID(DecChargeId); GetSingleData(DecChargeId); setArrestID(DecArrestId); get_ArrestCharge_Count(DecChargeId);
    }
    // else {
    //   navigate(`/Arr-Charge-Home?IncId=${IncID}&IncNo=${IncNo}&IncSta=${IncSta}&ChargeSta=${true}`)

    // }
  }, [DecChargeId]);

  const check_Validation_Error = (e) => {
    if (RequiredFieldIncident(value.NIBRSID)) {
      setErrors(prevValues => { return { ...prevValues, ['NIBRSIDError']: RequiredFieldIncident(value.NIBRSID) } })
    }
    if (RequiredFieldIncident(value.ChargeCodeID)) {
      setErrors(prevValues => { return { ...prevValues, ['ChargeCodeIDError']: RequiredFieldIncident(value.ChargeCodeID) } })
    }
  }

  // Check All Field Format is True Then Submit 
  const { ChargeCodeIDError, NIBRSIDError } = errors

  useEffect(() => {
    if (ChargeCodeIDError === 'true' && NIBRSIDError === 'true') {
      // (ChargeSta === true || ChargeSta === 'true') && ChargeID)
      if (ChargeID) { update_Arrest_Charge() }
      else { Add_Charge_Data() }
    }
  }, [ChargeCodeIDError, NIBRSIDError])

  useEffect(() => {
    if (ChargeID) {
      GetSingleData(ChargeID)
    }
  }, [ChargeID])

  const GetSingleData = (ChargeID) => {
    const val = {
      'ChargeID': ChargeID,
    }
    fetchPostData('ArrestCharge/GetSingleData_ArrestCharge', val)
      .then((res) => {
        if (res) {
          // setChangesStatus(false)
          setEditval(res);
        } else { setEditval([]) }
      })
  }

  useEffect(() => {
    if (ChargeID) {
      setValue({
        ...value,
        'Count': Editval[0]?.Count ? Editval[0]?.Count : '',
        'Name': Editval[0]?.Name,
        'ChargeCodeID': Editval[0]?.ChargeCodeID,
        'NIBRSID': Editval[0]?.NIBRSID,
        'UCRClearID': Editval[0]?.UCRClearID, 'ChargeID': Editval[0]?.ChargeID, 'ModifiedByUserFK': LoginPinID,
      });
      get_ChargeCode_Drp_Data(Editval[0]?.NIBRSID);
      setArrestName(Editval[0]?.Arrestee_Name ? Editval[0]?.Arrestee_Name : '');
    } else {
      setValue({
        ...value,
        'Count': '', 'ChargeCodeID': '', 'NIBRSID': '', 'UCRClearID': '', 'ChargeID': '', 'Name': ArresteName, 'ArrestNumber': ArrNo,
      })
    }
  }, [Editval])

  const Reset = () => {
    setValue({
      ...value,
      'CreatedByUserFK': '', 'Count': '', 'ChargeCodeID': '',
      'NIBRSID': '', 'UCRClearID': '', 'WarrantID': '',
    })
    setErrors({
      ...errors,
      ['NIBRSIDError']: '',
    });
  }

  const get_UcrClear_Drp_Data = (LoginAgencyID) => {
    const val = {
      AgencyID: LoginAgencyID,
    }
    fetchPostData('UCRClear/GetDataDropDown_UCRClear', val).then((data) => {
      if (data) {
        setUcrClearDrp(Comman_changeArrayFormat(data, 'UCRClearID', 'Description'));
      }
      else {
        setUcrClearDrp([])
      }
    })
  };

  const get_NIBRS_Drp_Data = (LoginAgencyID) => {
    const val = {
      AgencyID: LoginAgencyID,
    }
    fetchPostData('FBICodes/GetDataDropDown_FBICodes', val).then((data) => {
      if (data) {
        setNibrsDrpData(threeColArrayWithCode(data, 'FBIID', 'Description', 'FederalSpecificFBICode'))
      } else {
        setNibrsDrpData([]);
      }
    })
  };

  const get_ChargeCode_Drp_Data = (FBIID) => {
    const val = {
      FBIID: FBIID
    }
    fetchPostData('ChargeCodes/GetDataDropDown_ChargeCodes', val).then((data) => {
      if (data) {
        setChargeCodeDrp(Comman_changeArrayFormat(data, 'ChargeCodeID', 'Description'))
      } else {
        setChargeCodeDrp([]);
      }
    })
  };


  const ChangeDropDown = (e, name) => {
    if (e) {
      if (name === 'NIBRSID') {
        get_ChargeCode_Drp_Data(e.value);
        setValue({
          ...value,
          [name]: e.value,
          ['ChargeCodeID']: '',
        });
      } else {
        setValue({
          ...value,
          [name]: e.value,
        });
      }
    } else if (e === null) {
      if (name === 'NIBRSID') {
        setValue({
          ...value,
          ['NIBRSID']: "",
          ['ChargeCodeID']: "",
        });
        get_ChargeCode_Drp_Data([]);
      } else {
        setValue({
          ...value,
          [name]: null
        });
      }
    } else {
      setValue({
        ...value,
        [name]: null
      })
    }
  }

  const HandleChange = (e) => {
    setValue({
      ...value,
      [e.target.name]: e.target.value,
    });
  };

  const Add_Charge_Data = () => {
    AddDeleteUpadate('ArrestCharge/Insert_ArrestCharge', value).then((res) => {
      if (res.success) {
        const parsedData = JSON.parse(res.data);
        const message = parsedData.Table[0].Message;
        toastifySuccess(message);
        get_Arrest_Count(ArrestID); get_Data_Arrest_Charge(ArrestID)
        setStatus(false); Reset();
        setChangesStatus(false)
        if (res.ChargeID) {
          get_ArrestCharge_Count(res.ChargeID)
          setChargeID(res.ChargeID);
          navigate(`/Arr-Charge-Home?IncId=${IncID}&ArrestId=${ArrestId}&IncNo=${res?.IncidentNumber}&Name=${res?.Arrestee_Name}&ArrestSta=${true}&ArrNo=${ArrNo}&ChargeId=${stringToBase64(res.ChargeID)}&ChargeSta=${true}`)
        }
        setUpdateCount(updateCount + 1)
        setErrors({ ...errors, ['ChargeCodeIDError']: '' })
      }
    })
  }

  const update_Arrest_Charge = () => {
    AddDeleteUpadate('ArrestCharge/Update_ArrestCharge', value).then((res) => {
      const parsedData = JSON.parse(res.data);
      const message = parsedData.Table[0].Message;
      toastifySuccess(message); get_Data_Arrest_Charge(ArrestID)
      setErrors({
        ...errors,
        ['ChargeCodeIDError']: ''
      })
    })
  }

  const DeleteArrestCharge = () => {
    const val = {
      'ChargeID': ChargeID,
      'DeletedByUserFK': LoginPinID
    }
    AddDeleteUpadate('ArrestCharge/Delete_ArrestCharge', val).then((res) => {
      if (res) {
        const parsedData = JSON.parse(res.data);
        const message = parsedData.Table[0].Message;
        toastifySuccess(message);
        get_Data_Arrest_Charge(ArrestID);
        get_Arrest_Count(ArrestID); Reset(''); setStatusFalse()
        get_ArrestCharge_Count(ChargeID); setStatus(false)
      } else console.log("Somthing Wrong");
    })
  }

  const columns = [
    {
      name: 'Arrest Number',
      selector: (row) => row.ArrestNumber,
      sortable: true
    },
    {
      name: 'NIBRS Description',
      selector: (row) => row.NIBRS_Description,
      sortable: true
    },
    {
      name: 'UCRClear Description',
      selector: (row) => row.UCRClear_Description,
      sortable: true
    },
    {
      name: <p className='text-end' style={{ position: 'absolute', top: '7px', right: 0 }}>Delete</p>,
      cell: row => <>
        <div style={{ position: 'absolute', top: 4, right: 5 }}>
          <span to={`#`} onClick={(e) => setChargeID(row.ChargeID)} className="btn btn-sm bg-green text-white px-1 py-0 mr-1" data-toggle="modal" data-target="#DeleteModal">
            <i className="fa fa-trash"></i>
          </span>
        </div>
      </>
    }
  ]

  const conditionalRowStyles = [
    {
      when: row => row.ChargeID === ChargeID,
      style: {
        backgroundColor: '#001f3fbd',
        color: 'white',
        cursor: 'pointer',
      },
    },
  ];

  const set_Edit_Value = (row) => {
    navigate(`/Arr-Charge-Home?IncId=${IncID}&IncNo=${IncNo}&IncSta=${IncSta}&ArrestId=${stringToBase64(row.ArrestID)}&Name=${Name}&ArrNo=${ArrNo}&ArrestSta=${true}&ChargeId=${stringToBase64(row.ChargeID)}&ChargeSta=${true}`);
    if (row.ChargeID || row.ArrestID) {
      get_ArrestCharge_Count(row.ChargeID);
      setErrors('');
      setStatus(true);
      setChargeID(row.ChargeID);
    }
  }

  const setStatusFalse = () => {
    // navigate(`/Arr-Charge-Home?IncId=${IncID}&IncNo=${IncNo}&IncSta=${IncSta}&ArrestId=${('')}&Name=${('')}&ArrestSta=${false}&ChargeSta=${false}`)
    setChargeID(''); setClickedRow(null); Reset(); setErrors(''); get_ArrestCharge_Count(''); setStatus(false)
  }

  // Custom Style
  const colourStyles = {
    control: (styles) => ({
      ...styles, backgroundColor: "#fce9bf",
      height: 20,
      minHeight: 30,
      fontSize: 14,
      margintop: 2,
      boxShadow: 0,
    }),
  };

  // custuom style withoutColor
  const customStylesWithOutColor = {
    control: base => ({
      ...base,
      height: 20,
      minHeight: 30,
      fontSize: 14,
      margintop: 2,
      boxShadow: 0,
    }),
  };

  return (
    <>
      <div className="col-12">
        <div className="row">
          <div className="col-2 col-md-2 col-lg-1 mt-2 pt-2">
            <label htmlFor="" className='new-label'>Name</label>
          </div>
          <div className="col-4 col-md-4 col-lg-3 mt-2 text-field">
            {/* <input type="text" className='readonlyColor' name='Name' value={value?.Name}value={Name ? Name : ''} required readOnly /> */}
            <input type="text" className='readonlyColor' name='Name' value={Name ? Name : ''} required readOnly />
          </div>
          <div className="col-2 col-md-2 col-lg-2 mt-2 pt-2">
            <label htmlFor="" className='new-label'>Incident Number</label>
          </div>
          <div className="col-4 col-md-4 col-lg-2 mt-2 text-field">
            <input type="text" className='readonlyColor' name='IncidentID' value={IncNo ? IncNo : ''} required readOnly />
          </div>
          <div className="col-2 col-md-2 col-lg-2 mt-2 pt-2">
            <label htmlFor="" className='new-label'>Arrest Number</label>
          </div>
          <div className="col-4 col-md-4 col-lg-2 mt-2 text-field">
            <input type="text" className='readonlyColor' name='ArrestNumber' value={ArrNo ? ArrNo : ''} required readOnly />
          </div>
          <div className="col-2 col-md-2 col-lg-1 mt-2 pt-2">
            <span data-toggle="modal" onClick={() => {
              setOpenPage('FBI Code')
            }} data-target="#ListModel" className='new-link'>
              NIBRS Code {errors.NIBRSIDError !== 'true' ? (
                <span style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.NIBRSIDError}</span>
              ) : null}
            </span>
          </div>
          <div className="col-4 col-md-4 col-lg-3 mt-2 ">
            <Select
              styles={colourStyles}
              name="NIBRSID"
              value={nibrsDrpData?.filter((obj) => obj.value === value?.NIBRSID)}
              isClearable
              options={nibrsDrpData}
              onChange={(e) => { ChangeDropDown(e, 'NIBRSID') }}
              placeholder="Select..."
            />
          </div>
          <div className="col-2 col-md-2 col-lg-2 mt-2 pt-2">
            <Link to={'/ListManagement?page=Charge%20Code&call=/Arr-Charge-Home'} className='new-link '>
              Charge Code/Description  {errors.ChargeCodeIDError !== 'true' ? (
                <span style={{ color: 'red', fontSize: '13px', margin: '0px', padding: '0px' }}>{errors.ChargeCodeIDError}</span>
              ) : null}
            </Link>
          </div>
          <div className="col-4 col-md-4 col-lg-6 mt-2 ">
            <Select
              name="ChargeCodeID"
              value={chargeCodeDrp?.filter((obj) => obj.value === value?.ChargeCodeID)}
              styles={colourStyles}
              isClearable
              options={chargeCodeDrp}
              onChange={(e) => { ChangeDropDown(e, 'ChargeCodeID') }}
              placeholder="Select..."
            />
          </div>
          <div className="col-2 col-md-2 col-lg-1 mt-2 pt-2">
            {/* <Link to={'/ListManagement?page=UCR%20Clear&call=/Arr-Charge-Home'} className='new-link '>
              UCR Clear
            </Link> */}
            <span data-toggle="modal" onClick={() => {
              setOpenPage('UCR Clear')
            }} data-target="#ListModel" className='new-link'>
              UCR Clear
            </span>
          </div>
          <div className="col-4 col-md-4 col-lg-3 mt-2 ">
            <Select
              styles={customStylesWithOutColor}
              name="UCRClearID"
              value={ucrclearDrp?.filter((obj) => obj.value === value?.UCRClearID)}
              isClearable
              options={ucrclearDrp}
              onChange={(e) => { ChangeDropDown(e, 'UCRClearID') }}
              placeholder="Select..."
            />
          </div>
          <div className="col-2 col-md-2 col-lg-2 mt-2 pt-2">
            <label htmlFor="" className='new-label'>Count</label>
          </div>
          <div className="col-4 col-md-4 col-lg-2 mt-2 text-field">
            <input type="text" name='Count' id='Count' onChange={HandleChange} value={value?.Count} className='' />
          </div>
        </div>
      </div>
      <div className="col-12 text-right mt-2 p-0">
        <button type="button" className="btn btn-sm btn-success mx-1 py-1 text-center" onClick={() => { setStatusFalse(); }}>New</button>
        {
          // (ChargeSta === true || ChargeSta === 'true') && ChargeID ?
          ChargeID ?
            <button type="button" className="btn btn-sm btn-success  mr-1" onClick={() => { check_Validation_Error(); }}>Update</button>
            :
            <button type="button" className="btn btn-sm btn-success" onClick={() => { check_Validation_Error(); }}>Save</button>
        }
      </div>
      <div className="col-12 mt-2">
        <DataTable
          dense
          columns={columns}
          data={arrestChargeData}
          selectableRowsHighlight
          highlightOnHover
          pagination
          onRowClicked={(row) => {
            setClickedRow(row);
            set_Edit_Value(row);
          }}
          fixedHeaderScrollHeight='250px'
          conditionalRowStyles={conditionalRowStyles}
          fixedHeader
          persistTableHead={true}
          customStyles={tableCustomStyles}
        />
      </div>
      <IdentifyFieldColor />
      <DeletePopUpModal func={DeleteArrestCharge} />
      <ListModal {...{ openPage, setOpenPage }} />

    </>

  )

}

export default Home

