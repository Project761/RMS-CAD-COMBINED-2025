function ChangeLogSection() {
    return (
        <div>ChangeLogSection</div>
    )
}

export default ChangeLogSection