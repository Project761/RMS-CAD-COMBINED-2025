export const Operator_Drp_Data = "Operator_Drp_Data";
export const Priority_Drp_Data = "Priority_Drp_Data";
export const Zone_Drp_Data = "Zone_Drp_Data";
export const IncidentDispositions_Drp_Data = "IncidentDispositions_Drp_Data";